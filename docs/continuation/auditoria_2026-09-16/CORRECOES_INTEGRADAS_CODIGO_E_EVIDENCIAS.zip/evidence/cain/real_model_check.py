import json
import os
import sys
from pathlib import Path

base = Path(__file__).resolve().parent
sys.dont_write_bytecode = True
sys.path[:0] = [str(base / 'src'), str(base / 'tests/integration')]
sys.path.append('C:/BRASILEIRAO/work/im26/.venv/Lib/site-packages')
os.environ['PYTHONUTF8'] = '1'
from cain.llm import OllamaLLM
from cain.research.analysis import review
import test_research_l0 as cases

root = base / 'real-model-qa'
root.mkdir(exist_ok=False)
service, scope, ingest, _, _ = cases.setup.__wrapped__(root)
source = (
    '| ID | hipótese | horizonte | estado | evidência | ressalva |\n'
    '|---|---|---|---|---|---|\n'
    '| QA-BR-001 | Modelo possui informação incremental versus mercado | H-24h | BLOCKED_PENDING_PIT_FEATURES | '
    'no model comparison executed | feature availability not proven |\n'
    '| QA-BR-002 | Modelo possui informação incremental versus mercado | H-6h | BLOCKED_PENDING_PIT_FEATURES | '
    'no model comparison executed | feature availability not proven |\n'
    '| QA-BR-003 | Modelo possui informação incremental versus mercado | H-1h | BLOCKED_PENDING_PIT_FEATURES | '
    'no model comparison executed | feature availability not proven |\n'
)
package = cases.publication(('QA-BR-001', 'QA-BR-002', 'QA-BR-003'), domain='brasileirao', text=source)
for record in package['records']:
    record['source_status'] = 'BLOCKED_PENDING_PIT_FEATURES'
    record['status_axis'] = 'scientific'
package = cases.reseal(package)
ingest(package)
provider = OllamaLLM(model='qwen3.5:4b', base_url='http://127.0.0.1:11439',
                     temperature=0.0, seed=42, timeout=240, num_ctx=8192,
                     num_predict=1024, max_input_bytes=6500, think=False)
questions = [
    ('single', 'Qual a interpretação da hipótese QA-BR-001 e de suas limitações?', 'QA-BR-001'),
    ('all', 'O que a fonte informa sobre QA-BR-001, QA-BR-002 e QA-BR-003, seus horizontes e evidências?', None),
    ('reverse', 'O que a fonte informa sobre QA-BR-003, QA-BR-002 e QA-BR-001, seus horizontes e evidências?', None),
]
for name, question, identity in questions:
    result = review(service, scope, question, provider, role='synthesis', source_id=identity)
    (root / f'{name}.json').write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
    print(json.dumps({'case': name, 'status': result['status'], 'explanation': result.get('explanation'),
                      'coverage': result.get('coverage')}, ensure_ascii=False), flush=True)
