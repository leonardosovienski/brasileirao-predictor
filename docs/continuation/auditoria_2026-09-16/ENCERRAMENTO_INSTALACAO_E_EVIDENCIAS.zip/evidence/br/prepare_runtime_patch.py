"""Freeze only the audited modules over the actually installed packages."""
import hashlib
import json
import shutil
from pathlib import Path

base = Path('C:/BRASILEIRAO/work/audit-fixes-20260915/runtime-closeout')
base.mkdir(exist_ok=False)
specs = {
    'br': {
        'site': 'C:/BRASILEIRAO/brasileirao-predictor/.venv/Lib/site-packages',
        'source': 'C:/BRASILEIRAO/work/audit-fixes-20260915/candidate',
        'packages': ['brasileirao_scripts', 'brasileirao_predictor'],
        'files': ['brasileirao_scripts/evaluate_h14_prospective.py',
                  'brasileirao_scripts/evaluate_h15_prospective.py',
                  'brasileirao_scripts/prospective_metrics.py'],
    },
    'cain': {
        'site': 'C:/CAIN/.venv/Lib/site-packages',
        'source': 'C:/CAIN/work/brasileirao-audit-20260915/src',
        'packages': ['cain'],
        'files': ['cain/research/analysis.py', 'cain/research/grounding.py',
                  'cain/research/workflows.py', 'cain/research/claim_tables.py'],
    },
}
for label, spec in specs.items():
    site, source = Path(spec['site']), Path(spec['source'])
    stage = base / label / 'stage'
    for package in spec['packages']:
        shutil.copytree(site / package, stage / package, ignore=shutil.ignore_patterns('__pycache__', '*.pyc'))
    manifest = []
    for relative in spec['files']:
        old, new = site / relative, source / relative
        old_bytes = old.read_bytes() if old.exists() else None
        if old_bytes is not None:
            backup = base / label / 'backup' / relative
            backup.parent.mkdir(parents=True, exist_ok=True)
            backup.write_bytes(old_bytes)
        target = stage / relative
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_bytes(new.read_bytes())
        manifest.append({'path': relative,
                         'before': hashlib.sha256(old_bytes).hexdigest() if old_bytes is not None else None,
                         'after': hashlib.sha256(new.read_bytes()).hexdigest()})
    spec['manifest'] = manifest
(base / 'manifest.json').write_text(json.dumps(specs, indent=2), encoding='utf-8')
print(base)
