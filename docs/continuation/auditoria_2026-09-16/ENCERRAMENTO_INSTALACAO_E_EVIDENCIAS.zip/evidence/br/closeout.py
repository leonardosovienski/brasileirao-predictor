import hashlib
import json
import zipfile
from pathlib import Path

base = Path(__file__).parent
deployment = base / 'runtime-closeout'
cain = Path('C:/CAIN/work/brasileirao-audit-20260915')
out = Path('C:/Users/leona/Documents/Codex/2026-09-15/lea/outputs')
specs = json.loads((deployment / 'manifest.json').read_text())
preserved = json.loads((deployment / 'preserved.json').read_text())
for path, expected in preserved.items():
    assert hashlib.sha256(Path(path).read_bytes()).hexdigest() == expected, path
assert '108 passed' in (base / 'runtime-installed.log').read_text(encoding='utf-8-sig')
assert '48 passed' in (cain / 'runtime-installed.log').read_text(encoding='utf-8-sig')
verified = {}
for label, spec in specs.items():
    stage = deployment / label / 'stage'
    count = 0
    for frozen in stage.rglob('*.py'):
        installed = Path(spec['site']) / frozen.relative_to(stage)
        assert installed.read_bytes() == frozen.read_bytes(), installed
        count += 1
    verified[label] = count
receipt = json.loads((deployment / 'deployment.json').read_text())
receipt.update({'installed_package_py_files_verified': verified,
                'installed_code_tests': {'brasileirao': 108, 'cain': 48},
                'preserved_hashes_verified': preserved,
                'scientific_evaluation_executed': False,
                'personal_database_opened': False,
                'dependency_changes': False,
                'cain_dependency_deprecation_warnings': 2})
(out / 'RECIBO_ENCERRAMENTO.json').write_text(json.dumps(receipt, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
report = '''# Encerramento — auditoria e correções do Brasileirão / CAIN

## Resultado em 15/09/2026

Auditoria documental E1–E6 entregue. As correções identificadas e implementáveis
com as evidências disponíveis foram integradas ao código e agora também aplicadas
às instalações operacionais. Não resta a pendência de instalar estes sete módulos.

- Brasileirão: três módulos na instalação `.venv` do projeto, incluindo os
  avaliadores H14/H15 e o componente puro de métricas.
- CAIN: quatro módulos de pesquisa em `C:/CAIN/.venv`, ambiente efetivamente
  selecionado pelo atalho `ABRIR_CAIN.cmd` por meio de `.cain.local.json`.
- Aplicação como patch local rastreável, sem publicar uma nova versão de pacote.
  Dependências, configuração, dados pessoais e agendamentos não foram alterados.
- Sete módulos com backup dos bytes anteriores; metadados RECORD atualizados.
  Os outros arquivos Python das instalações conferem com o estado preparado.

## Validação concluída

Primeiro foram testadas cópias das instalações com apenas esses módulos alterados:
108 testes Brasileirão e 48 CAIN passaram. Depois da aplicação, os mesmos conjuntos
passaram novamente carregando os pacotes instalados: **108 + 48, sem falhas**.
Os dados dos testes são sintéticos e os bancos ficam em QA.
Os testes não avaliam coortes protegidas nem abrem o banco pessoal.
Há dois avisos de depreciação de dependências do CAIN; não são falhas dos testes.

O primeiro ensaio de instalação encontrou uma restrição excessiva do harness ao
ler o pytest de QA. O caminho de ferramentas foi liberado sem liberar os dados
protegidos; o log da tentativa está preservado. As tentativas de geração real
anteriores também permanecem nos pacotes anteriores, inclusive a resposta
semanticamente incorreta e a falha de geração.

Os hashes das previsões originais H14/H15 e dos arquivos de configuração
selecionados foram conferidos novamente. A correção literal de tabelas mantém
IDs, horizontes, estados e ressalvas; não certifica toda geração livre do modelo.

## Lacunas que permanecem registradas

| Item | Estado final e requisito para avançar |
| --- | --- |
| Previsões antigas H15 | 2 de 6 previsões por braço reconstruídas retrospectivamente, em suplemento separado. As outras 4 precisam de estado/configuração histórica compatível. Originais mantidos. |
| Previsões antigas H14 | Probabilidades OU2.5 e baseline histórica insuficientes. Não há reconstrução única a partir de 1X2. |
| Avaliação protegida H14/H15 | Bloqueio preventivo instalado. Resolver documentação da baseline OU2.5, definição dos p-values e demais lacunas de protocolo antes de qualquer avaliação. A função Holm isolada não completa o protocolo. |
| Fontes documentais | Dois relatórios EXP-001 ausentes no inventário consultado; identidade integrated_xg_v2 e ligação histórica H11 dependem de fontes adicionais. |
| Qualidade preditiva e semântica geral | Esta entrega não constitui nova validação científica, econômica ou certificação de toda resposta do CAIN. |

Essas lacunas não foram encerradas com valores inventados, alteração de contratos
congelados ou leitura de resultados protegidos. São dependências de evidência,
não tarefas de implementação restantes que possam ser resolvidas honestamente
com o material disponível.

## Rastreabilidade e reversão

Recibo final: `RECIBO_ENCERRAMENTO.json`. Entrega anterior detalhada:
`PARECER_E_CORRECOES.md`, `CONTINUACAO_REPAROS.md` e
`CORRECOES_INTEGRADAS.md`. Esses documentos são registros das respectivas etapas;
a indicação anterior de “instalação não atualizada” foi superada por este encerramento.

Backup e manifesto locais:
`C:/BRASILEIRAO/work/audit-fixes-20260915/runtime-closeout`.
Reversão, se necessária, com aplicativos encerrados:

```powershell
& C:/CAIN/.venv/Scripts/python.exe C:/BRASILEIRAO/work/audit-fixes-20260915/deploy_runtime_patch.py --rollback
```

A reversão confere hashes e recusa sobrescrever alterações posteriores. Uma
reinstalação futura dos pacotes pode substituir este patch: antes dela, levar
as correções dos checkouts para a versão que será instalada.

Não houve commit, push, merge nem publicação por esta execução. Não se afirma
ausência universal de bugs: os resultados estão limitados aos casos e bytes
verificados. O trabalho implementável desta auditoria está encerrado.
'''
(out / 'ENCERRAMENTO.md').write_text(report, encoding='utf-8')
with zipfile.ZipFile(out / 'ENCERRAMENTO_INSTALACAO_E_EVIDENCIAS.zip', 'w', zipfile.ZIP_DEFLATED) as bundle:
    for name in ['ENCERRAMENTO.md', 'RECIBO_ENCERRAMENTO.json']:
        bundle.write(out / name, name)
    for name in ['prepare_runtime_patch.py', 'deploy_runtime_patch.py', 'closeout.py',
                 'run_runtime_stage.py', 'run_runtime_installed.py', 'runtime-stage.log',
                 'runtime-stage-02.log', 'runtime-installed.log', 'runtime-installed-results.xml']:
        bundle.write(base / name, 'evidence/br/' + name)
    for name in ['run_runtime_stage.py', 'run_runtime_installed.py', 'runtime-stage.log', 'runtime-installed.log']:
        bundle.write(cain / name, 'evidence/cain/' + name)
    for name in ['manifest.json', 'deployment.json', 'preserved.json']:
        bundle.write(deployment / name, 'runtime/' + name)
    for label, spec in specs.items():
        bundle.write(deployment / label / 'RECORD.before', f'runtime/{label}/RECORD.before')
        for entry in spec['manifest']:
            for area in ['stage', 'backup']:
                p = deployment / label / area / entry['path']
                if p.exists():
                    bundle.write(p, f'runtime/{label}/{area}/' + entry['path'])
with zipfile.ZipFile(out / 'ENCERRAMENTO_INSTALACAO_E_EVIDENCIAS.zip') as bundle:
    assert bundle.testzip() is None
print(json.dumps({'closed': True, 'installed_python_files_verified': verified,
                  'tests': 156, 'preserved_files': len(preserved)}))
