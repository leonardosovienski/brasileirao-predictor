"""Apply/revert seven frozen modules, with byte-level concurrency checks and backups."""
import base64
import csv
import hashlib
import io
import json
import os
import sys
from datetime import datetime, timezone
from pathlib import Path

base = Path(__file__).parent / 'runtime-closeout'
specs = json.loads((base / 'manifest.json').read_text())
rollback = '--rollback' in sys.argv
records = {'br': 'brasileirao_predictor-0.2.0.dist-info/RECORD',
           'cain': 'cain_research-0.4.12.dist-info/RECORD'}


def digest(data):
    return hashlib.sha256(data).hexdigest() if data is not None else None


def write(path, data):
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_name(path.name + '.br-audit-tmp')
    with temporary.open('xb') as stream:
        stream.write(data)
    os.replace(temporary, path)


if not rollback:
    assert '108 passed' in (base.parent / 'runtime-stage-02.log').read_text(encoding='utf-8-sig')
    assert '48 passed' in Path('C:/CAIN/work/brasileirao-audit-20260915/runtime-stage.log').read_text(encoding='utf-8-sig')
    assert not (base / 'deployment.json').exists(), 'Already deployed'
else:
    assert (base / 'deployment.json').exists()

changes = []
for label, spec in specs.items():
    site = Path(spec['site']).resolve()
    for entry in spec['manifest']:
        target = (site / entry['path']).resolve()
        assert target.is_relative_to(site)
        old = target.read_bytes() if target.exists() else None
        assert digest(old) == entry['after' if rollback else 'before'], f'Concurrent change: {target}'
        content_path = base / label / ('backup' if rollback else 'stage') / entry['path']
        content = content_path.read_bytes() if content_path.exists() else None
        assert digest(content) == entry['before' if rollback else 'after']
        changes.append((target, old, content))
    record = site / records[label]
    original = record.read_bytes()
    backup = base / label / 'RECORD.before'
    if rollback:
        assert digest(original) == json.loads((base / 'deployment.json').read_text())['records'][label]
        new_record = backup.read_bytes()
    else:
        backup.write_bytes(original)
        rows = list(csv.reader(io.StringIO(original.decode())))
        updated = {e['path'] for e in spec['manifest']}
        rows = [row for row in rows if row[0] not in updated]
        for entry in spec['manifest']:
            content = (base / label / 'stage' / entry['path']).read_bytes()
            encoded = base64.urlsafe_b64encode(hashlib.sha256(content).digest()).rstrip(b'=').decode()
            rows.append([entry['path'], 'sha256=' + encoded, str(len(content))])
        stream = io.StringIO(newline='')
        csv.writer(stream).writerows(rows)
        new_record = stream.getvalue().encode()
    changes.append((record, original, new_record))

applied = []
try:
    for target, old, content in changes:
        assert (target.read_bytes() if target.exists() else None) == old
        if content is None:
            target.unlink()
        else:
            write(target, content)
        applied.append((target, old))
except BaseException:
    for target, old in reversed(applied):
        if old is None:
            target.unlink(missing_ok=True)
        else:
            write(target, old)
    raise
receipt = {'at': datetime.now(timezone.utc).isoformat(), 'rollback': rollback,
           'kind': 'local auditable patch; not a new published package release',
           'files': specs, 'records': {label: digest((Path(spec['site']) / records[label]).read_bytes())
                                      for label, spec in specs.items()}}
(base / ('rollback.json' if rollback else 'deployment.json')).write_text(json.dumps(receipt, indent=2), encoding='utf-8')
print(json.dumps({'deployed': not rollback, 'modules': 7, 'dependencies_changed': False}))
