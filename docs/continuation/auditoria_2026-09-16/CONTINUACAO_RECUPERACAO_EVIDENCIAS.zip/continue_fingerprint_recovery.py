"""Investigate serialization-equivalent configs, never optimize numeric values."""
import copy
import hashlib
import itertools
import json
import math
import subprocess
import zipfile
from pathlib import Path

import yaml

BASE = Path(__file__).parent
OUT = BASE / 'continued-recovery'
OUT.mkdir(exist_ok=True)
data = json.loads((BASE / 'expanded-recovery/candidates.json').read_text(encoding='utf-8'))
original = (BASE / 'forecast-recovery/originals/h15_refit10_vs_100.jsonl').read_bytes()
rows = [json.loads(line) for line in original.decode().splitlines() if line.strip()]


def hashed(value):
    return hashlib.sha256(json.dumps(value, sort_keys=True).encode()).hexdigest()[:16]


def read_candidate(path):
    if path.startswith('git:'):
        _, commit, name = path.split(':', 2)
        return subprocess.check_output(['git', 'show', commit + ':' + name], cwd='C:/BRASILEIRAO/brasileirao-predictor')
    if '::' in path:
        archive, name = path.split('::', 1)
        with zipfile.ZipFile(archive) as z:
            return z.read(name)
    return Path(path).read_bytes()


def numbers(value, prefix=()):
    if isinstance(value, dict):
        for key, child in value.items():
            yield from numbers(child, prefix + (key,))
    elif type(value) in (int, float) and math.isfinite(value) and value == int(value):
        yield prefix


seen, searched, matches = set(), [], []
for entry in data['configs']:
    if entry['config_hash'] in seen:
        continue
    seen.add(entry['config_hash'])
    raw = read_candidate(entry['path'])
    assert hashlib.sha256(raw).hexdigest() == entry['sha256']
    cfg = yaml.safe_load(raw)
    relevant = {'model_algorithm_version': 'nbdc-normalized-elo-horizon-v2', 'elo': cfg['elo'],
                'calibration_window_years': cfg['model']['calibration_window_years'],
                'goal_half_life_days': cfg['model']['goal_half_life_days']}
    if (cfg.get('ensemble_xg') or {}).get('enabled'):
        relevant['ensemble_xg'] = cfg['ensemble_xg']
    assert hashed(relevant) == entry['config_hash']
    paths = list(numbers(relevant))
    assert len(paths) <= 18, 'Bounded exact-equivalence investigation only'
    count = 0
    for mask in itertools.product((False, True), repeat=len(paths)):
        value = copy.deepcopy(relevant)
        for path, floating in zip(paths, mask, strict=True):
            parent = value
            for key in path[:-1]:
                parent = parent[key]
            parent[path[-1]] = float(parent[path[-1]]) if floating else int(parent[path[-1]])
        assert value == relevant, 'Numeric value changed'
        fingerprint = hashed(value)
        count += 1
        for row in rows:
            for arm, cadence in [('control_refit100', 100), ('treatment_refit10', 10)]:
                design = {'trial': 'h15-refit10-vs-100-serving-v2-prospectivo', 'arm': arm,
                          'retrain_every': cadence, 'algorithm_version': 'nbdc-normalized-elo-horizon-v2',
                          'config_hash': fingerprint, 'home_advantage': entry['home_adv']}
                if hashed(design) == row[arm]['code_fingerprint']:
                    matches.append({'event_id': row['event_id'], 'arm': arm,
                                    'archived_configuration': entry, 'equivalent_relevant_config': value,
                                    'config_hash': fingerprint, 'original_serialization': fingerprint == entry['config_hash']})
    searched.append({'configuration': entry, 'equivalent_numeric_representations': count})
result = {'method': 'enumerate int/float serialization with all numeric values unchanged',
          'original_forecasts_sha256': hashlib.sha256(original).hexdigest(),
          'outcomes_used': False, 'numeric_values_optimized': False, 'searched': searched, 'matches': matches}
(OUT / 'equivalent-config-search.json').write_text(json.dumps(result, indent=2), encoding='utf-8')
print(json.dumps({'representations_examined': sum(r['equivalent_numeric_representations'] for r in searched),
                  'matching_arms': sorted({str(m['event_id']) + '/' + m['arm'] for m in matches}),
                  'new_equivalent_config_matches': sum(not m['original_serialization'] for m in matches)}))
