"""Inspect unreferenced Git blobs for configuration structure; never evaluate outcomes."""
import hashlib
import json
import subprocess
from pathlib import Path
import yaml

BASE = Path(__file__).parent
REPO = 'C:/BRASILEIRAO/brasileirao-predictor'
def git(*args):
    return subprocess.check_output(['git', '-C', REPO, *args])

listing = git('fsck', '--full', '--unreachable', '--no-reflogs').decode()
records = []
found = []
for line in listing.splitlines():
    parts = line.split()
    if len(parts) != 3 or parts[1] != 'blob':
        continue
    oid = parts[2]
    raw = git('cat-file', 'blob', oid)
    item = {'oid': oid, 'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()}
    try:
        # Only parse plausible bounded YAML/JSON configurations.
        text = raw.decode('utf-8')
        if len(raw) < 200000 and 'elo' in text and 'calibration_window_years' in text:
            value = yaml.safe_load(text)
            if isinstance(value, dict) and isinstance(value.get('elo'), dict) and isinstance(value.get('model'), dict):
                path = BASE / 'continued-recovery' / ('dangling-config-' + oid + '.yaml')
                path.write_bytes(raw)
                found.append(str(path))
                item['configuration_candidate'] = str(path)
    except (UnicodeError, yaml.YAMLError):
        pass
    records.append(item)
tree = git('ls-tree', '-r', '--name-only', '7324b9b8babc22fe84e2337f3ff9f697acf53031').decode().splitlines()
targets = ['reports/exp001_data_pilot_2026-09-02.json', 'reports/exp001_coverage_audit_2026-09-02.json']
result = {'objects': listing.splitlines(), 'blobs_inspected': records, 'configuration_candidates': found,
          'missing_report_hits': [p for p in targets if p in tree], 'tree_file_count': len(tree)}
out = BASE / 'continued-recovery/dangling-git-search.json'
out.write_text(json.dumps(result, indent=2), encoding='utf-8')
print(json.dumps({'blobs': len(records), 'configurations': found, 'reports': result['missing_report_hits']}))
