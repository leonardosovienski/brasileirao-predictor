"""Verify release checksum and list relevant archive names without executing code."""
import hashlib
import json
import tarfile
import urllib.request
from pathlib import Path

base = Path(__file__).parent / 'continued-recovery'
metadata = json.loads((base / 'github-search.json').read_text())
asset = next(a for r in metadata['releases'] for a in r['assets'] if a['name'].endswith('.tar.gz'))
path = base / asset['name']
if path.exists():
    raw = path.read_bytes()
else:
    with urllib.request.urlopen(asset['url'], timeout=60) as response:
        raw = response.read(20_000_001)
assert len(raw) == asset['size'] < 20_000_000
digest = hashlib.sha256(raw).hexdigest()
assert 'sha256:' + digest == asset['digest']
path.write_bytes(raw)
with tarfile.open(path, 'r:gz') as archive:
    names = archive.getnames()
    known = json.loads((base.parent / 'expanded-recovery/candidates.json').read_text(encoding='utf-8'))
    known_hashes = {entry['sha256'] for entry in known['configs']}
    config_checks = []
    for name in names:
        if name.endswith('/config.yaml'):
            config_raw = archive.extractfile(name).read()
            config_sha = hashlib.sha256(config_raw).hexdigest()
            config_checks.append({'name': name, 'sha256': config_sha, 'already_examined': config_sha in known_hashes})
targets = ('exp001_data_pilot_2026-09-02.json', 'exp001_coverage_audit_2026-09-02.json')
result = {'url': asset['url'], 'sha256': digest, 'checksum_verified': True,
          'members': len(names), 'configuration_checks': config_checks,
          'missing_report_hits': [n for n in names if n.endswith(targets)],
          'configuration_or_state_names': [n for n in names if n.endswith(('config.yaml', 'state.json', 'states.json'))]}
(base / 'release-archive-search.json').write_text(json.dumps(result, indent=2), encoding='utf-8')
print(json.dumps(result))
