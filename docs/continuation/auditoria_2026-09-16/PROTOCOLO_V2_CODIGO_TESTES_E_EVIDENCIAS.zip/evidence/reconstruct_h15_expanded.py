"""Bounded archived config/state recovery. No observed outcomes are opened."""
import hashlib
import json
import platform
import sys
from datetime import datetime
from pathlib import Path

import yaml

base = Path(__file__).resolve().parent
root = base / 'forecast-recovery'
archive = Path('C:/BRASILEIRAO/DADOS_PRESERVADOS')
sys.dont_write_bytecode = True
sys.path.insert(0, str(base / 'candidate'))
candidates = json.loads((base / 'expanded-recovery/candidates.json').read_text(encoding='utf-8'))
configs, states = candidates['configs'], candidates['states']
platform.uname()


def audit(event, args):
    if event.startswith('socket.') or event in {'subprocess.Popen', 'os.system', 'sqlite3.connect'}:
        raise RuntimeError('No network, subprocess or DB in reconstruction')
    if event == 'open' and isinstance(args[0], str) and Path(args[0]).resolve().is_relative_to(archive):
        raise RuntimeError('No more archive reads after input freeze')


sys.addaudithook(audit)
from brasileirao_predictor import model

original = root / 'originals/h15_refit10_vs_100.jsonl'
raw = original.read_bytes()
output = {'classification': 'RETROSPECTIVE_RECONSTRUCTION_NOT_ORIGINAL_FORECAST',
          'original_sha256': hashlib.sha256(raw).hexdigest(), 'outcomes_used': False,
          'original_code_identity_proven': False, 'prospective_eligibility_restored': False,
          'model_source_sha256': hashlib.sha256(Path(model.__file__).read_bytes()).hexdigest(),
          'configuration_candidates': configs,
          'state_candidates': [{k: value[k] for k in ('path', 'sha256', 'arm')} for value in states],
          'records': []}
for line in raw.decode('utf-8').splitlines():
    if not line.strip():
        continue
    row = json.loads(line)
    repaired = {'event_id': row['event_id'], 'predicted_at': row['predicted_at'], 'arms': {}}
    for arm, cadence in [('control_refit100', 100), ('treatment_refit10', 10)]:
        old, candidates = row[arm], []
        for state_entry in states:
            state = state_entry['state']
            if state_entry['arm'] != arm or state['refit_at'] != old['refit_at']:
                continue
            if not (datetime.fromisoformat(state['refit_at']) <= datetime.fromisoformat(row['predicted_at'])
                    < datetime.fromisoformat(row['kickoff_at'])):
                continue
            if any(round(state['elo'][row[team]], 1) != old[key]
                   for team, key in [('home', 'elo_home'), ('away', 'elo_away')]):
                continue
            for cfg in configs:
                policy = {'trial': 'h15-refit10-vs-100-serving-v2-prospectivo', 'arm': arm,
                          'retrain_every': cadence, 'algorithm_version': 'nbdc-normalized-elo-horizon-v2',
                          'config_hash': cfg['config_hash'], 'home_advantage': cfg['home_adv']}
                if hashlib.sha256(json.dumps(policy, sort_keys=True).encode()).hexdigest()[:16] != old['code_fingerprint']:
                    continue
                pred = model.predict_match(state['elo'][row['home']], state['elo'][row['away']],
                                           tuple(state['params']), cfg['home_adv'])
                if all(round(pred[new], 6) == old[key] for key, new in
                       [('p_home', 'p_win'), ('p_draw', 'p_draw'), ('p_away', 'p_loss')]):
                    candidates.append({'p_over_2_5': float(pred['over'][2.5]),
                                       'state_sha256': state_entry['sha256'], 'config_sha256': cfg['sha256']})
        values = {candidate['p_over_2_5'] for candidate in candidates}
        repaired['arms'][arm] = {
            'status': 'RECONSTRUCTED_RETROSPECTIVE' if len(values) == 1 else
                      'AMBIGUOUS_RECONSTRUCTION' if values else 'UNRECOVERED',
            'p_over_2_5': next(iter(values)) if len(values) == 1 else None,
            'matching_provenance': candidates,
        }
    output['records'].append(repaired)
assert original.read_bytes() == raw
with (root / 'h15-retrospective-supplement-v3.json').open('x', encoding='utf-8') as stream:
    json.dump(output, stream, indent=2, allow_nan=False)
print(json.dumps({'arm_forecasts': sum(len(r['arms']) for r in output['records']),
                  'reconstructed': sum(a['status'] == 'RECONSTRUCTED_RETROSPECTIVE'
                                       for r in output['records'] for a in r['arms'].values()),
                  'configurations_examined': len(configs), 'state_files_examined': len(states)}))
