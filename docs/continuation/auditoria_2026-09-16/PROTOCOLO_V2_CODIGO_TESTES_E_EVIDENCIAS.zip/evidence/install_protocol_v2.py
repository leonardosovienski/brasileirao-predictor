"""Install the tested successor module only; never activate a cohort."""
import base64
import csv
import hashlib
import io
import json
import os
import sys
from datetime import datetime, timezone
from pathlib import Path

base = Path(__file__).parent
backup = base / 'protocol-v2-installation'
site = Path('C:/BRASILEIRAO/brasileirao-predictor/.venv/Lib/site-packages')
repo = Path('C:/BRASILEIRAO/brasileirao-predictor')
relative = 'brasileirao_scripts/prospective_protocol_v2.py'
target = site / relative
record = site / 'brasileirao_predictor-0.2.0.dist-info/RECORD'


def sha(data):
    return hashlib.sha256(data).hexdigest()


def replace_record(data):
    tmp = record.with_name('RECORD.protocol-v2.tmp')
    with tmp.open('xb') as stream:
        stream.write(data)
    os.replace(tmp, record)


if '--rollback' in sys.argv:
    receipt = json.loads((backup / 'receipt.json').read_text())
    assert sha(target.read_bytes()) == receipt['module_sha256']
    assert sha(record.read_bytes()) == receipt['record_after_sha256']
    target.unlink()
    replace_record((backup / 'RECORD.before').read_bytes())
    print('Runtime module reverted; source/test files retained')
    raise SystemExit(0)

assert '155 passed' in (base / 'protocol-v2-tests-final.log').read_text(encoding='utf-8-sig')
payload = (base / 'candidate' / relative).read_bytes()
assert not target.exists() and not backup.exists()
source_paths = [relative, 'tests/test_prospective_protocol_v2.py']
assert all(not (repo / name).exists() for name in source_paths)
old_record = record.read_bytes()
rows = list(csv.reader(io.StringIO(old_record.decode())))
assert not any(row[0] == relative for row in rows)
encoded = base64.urlsafe_b64encode(hashlib.sha256(payload).digest()).rstrip(b'=').decode()
rows.append([relative, 'sha256=' + encoded, str(len(payload))])
output = io.StringIO(newline='')
csv.writer(output).writerows(rows)
new_record = output.getvalue().encode()
backup.mkdir()
(backup / 'RECORD.before').write_bytes(old_record)
created = []
try:
    for name in source_paths:
        with (repo / name).open('xb') as stream:
            stream.write((base / 'candidate' / name).read_bytes())
        created.append(repo / name)
    with target.open('xb') as stream:
        stream.write(payload)
    created.append(target)
    assert record.read_bytes() == old_record, 'Concurrent package metadata change'
    replace_record(new_record)
except BaseException:
    for path in created:
        path.unlink()
    raise
receipt = {'at': datetime.now(timezone.utc).isoformat(), 'module_sha256': sha(payload),
           'installed': str(target), 'record_before_sha256': sha(old_record),
           'record_after_sha256': sha(new_record), 'collection_activated': False,
           'legacy_protocol_changed': False, 'dependencies_changed': False,
           'source_files': {name: sha((repo / name).read_bytes()) for name in source_paths}}
(backup / 'receipt.json').write_text(json.dumps(receipt, indent=2), encoding='utf-8')
print(json.dumps(receipt))
