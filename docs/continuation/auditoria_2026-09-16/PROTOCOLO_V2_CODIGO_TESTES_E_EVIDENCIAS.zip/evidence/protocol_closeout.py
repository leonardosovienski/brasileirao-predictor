import hashlib
import json
import shutil
import sys
import zipfile
from pathlib import Path

sys.dont_write_bytecode = True
from brasileirao_scripts import prospective_protocol_v2 as protocol

base = Path(__file__).parent
out = Path('C:/Users/leona/Documents/Codex/2026-09-15/lea/outputs')
repo = Path('C:/BRASILEIRAO/brasileirao-predictor')
assert '155 passed' in (base / 'protocol-v2-installed.log').read_text(encoding='utf-8-sig')
assert 'site-packages' in protocol.__file__
source = repo / 'brasileirao_scripts/prospective_protocol_v2.py'
assert source.read_bytes() == Path(protocol.__file__).read_bytes() == (
    base / 'candidate/brasileirao_scripts/prospective_protocol_v2.py').read_bytes()
preserved = json.loads((base / 'runtime-closeout/preserved.json').read_text())
for path, expected in preserved.items():
    assert hashlib.sha256(Path(path).read_bytes()).hexdigest() == expected
for filename, expected in {
    'trials.json': 'e5af7c0ffd79298a66a446b02973b0be9827c0fe987e94185b0b9a035f4e1199',
    'trials.v2.json': 'fbad9c0cf5af78016b5480ab2384db0bb356f4b07c79a08628aba23ba10e7d90',
}.items():
    current = repo / 'data' / filename
    assert hashlib.sha256(current.read_bytes()).hexdigest() == expected, filename
    preserved[str(current)] = hashlib.sha256(current.read_bytes()).hexdigest()
spec = protocol.specification()
(out / 'PROTOCOLO_SUCESSOR_V2.json').write_text(json.dumps(spec, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
docs = repo / 'docs/research'
docs.mkdir(exist_ok=True)
with (docs / 'prospective_repair_v2_20260915.json').open('x', encoding='utf-8') as stream:
    json.dump(spec, stream, ensure_ascii=False, indent=2)
inventory = json.loads((base / 'expanded-recovery/candidates.json').read_text())
summary = {key: inventory[key] for key in ('archives', 'report_hits', 'git_config_commits_examined', 'errors', 'outcomes_read')}
summary['configurations'] = inventory['configs']
summary['states'] = [{k: value[k] for k in ('path', 'sha256', 'arm')} for value in inventory['states']]
summary['unique_configurations'] = len({c['config_hash'] for c in inventory['configs']})
summary['unique_states'] = len({s['sha256'] for s in inventory['states']})
(out / 'BUSCA_HISTORICA_AMPLIADA.json').write_text(json.dumps(summary, ensure_ascii=False, indent=2), encoding='utf-8')
supplement = base / 'forecast-recovery/h15-retrospective-supplement-v3.json'
shutil.copyfile(supplement, out / 'H15_SUPLEMENTO_RETROSPECTIVO_V3.json')
receipt = json.loads((base / 'protocol-v2-installation/receipt.json').read_text())
receipt.update({'installed_tests': 155, 'new_test_cases': 47, 'random_scoring_cases': 200,
                'lint': 'passed', 'installed_module': protocol.__file__,
                'protocol_sha256': protocol.content_hash(spec),
                'preserved_hashes': preserved, 'historical_arms_reconstructed': 2,
                'historical_arms_total': 6, 'new_historical_arms_recovered': 0,
                'scientific_evaluation_executed': False, 'bug_absence_proven': False})
(out / 'RECIBO_PROTOCOLO_V2.json').write_text(json.dumps(receipt, ensure_ascii=False, indent=2), encoding='utf-8')
report = '''# Dados históricos e protocolos — resultado da nova rodada

## Resultado

Foi implementada e instalada uma versão sucessora explícita de protocolo,
`br-prospective-repair-v2-20260915`, com cálculos e validação de entradas.
**155 testes passaram carregando o código instalado**, sendo 47 casos novos.
Um desses testes compara 200 combinações aleatórias de probabilidades e placares
com as métricas do Core. Ruff passou. Não houve nova alteração no CAIN.
Isso confirma os casos testados, não ausência universal de bugs.

A busca histórica foi ampliada, mas **não recuperou novas previsões**.
Continuam reconstruídas retrospectivamente 2 das 6 previsões por braço H15.
Não se restaurou validade prospectiva nem identidade completa do código original.

## O que foi especificado e implementado

- Climatologia 1X2 Dirichlet(1,1,1) e OU2.5 Beta(1,1), com fórmulas explícitas.
- Bloco pela data UTC da partida; corte fixo às 00:00 UTC do dia anterior.
  Essa escolha nova, mais conservadora, permite a janela de previsão de 24 horas.
  Só entram resultados finalizados e disponíveis estritamente antes do corte.
  São exigidos pelo menos 200 jogos; chegadas tardias não mudam o snapshot anterior.
- Registro com probabilidades completas, estado do modelo, código, configuração,
  corte de treino, timestamps e hashes. A baseline deve ser reproduzível a partir
  do histórico incluído no registro. A probabilidade OU2.5 não pode ser omitida.
- Recibos precisam preceder o kickoff. Hashes e consistência temporal são
  verificados; autenticar a origem e o timestamp do recibo continua sendo uma
  exigência externa de admissão, não algo que um hash sozinho prove.
- Amostra conjunta previamente congelada de exatamente 900 eventos por membro,
  com mesmos IDs e kickoffs. Duplicatas, perdas silenciosas, resultados incompletos,
  dados adulterados e mistura com registros legados são rejeitados.
- Métricas RPS, log loss, Brier 1X2 e Brier OU2.5, com ordem de classes e escalas
  explícitas. Ganho positivo significa perda do controle menos perda do tratamento.
- Bootstrap móvel não circular, blocos de 21 jogos, 10.000 replicações, PCG64/seed 42,
  IC percentil, p-value unilateral sobre médias reamostradas centradas na hipótese nula.
  Empates contam na cauda; correção (1 + contagem)/(10000 + 1). Série constante é
  inconclusiva, com p=1, e não pode aprovar um modelo.
- Holm a 5% sobre a família completa. Exige-se também limite inferior positivo
  no RPS e não negativo em cada guardrail. Intervalo incerto não vira “sem piora”.
- As funções não abrem bancos nem ledgers, não treinam modelos e não ativam tarefas.
  Recebem entradas explícitas. As saídas mantêm autorização científica e capital falsos.

Essas definições são **escolhas novas declaradas**, não conteúdo atribuído ao
pré-registro de agosto. Os contratos antigos e seus bloqueios foram preservados.
A versão nova está disponível como biblioteca e especificação, ainda sem ativação
de coleta, sem nova inscrição canônica e sem avaliação de coorte real.
Para uma futura ativação, a configuração exata, a identidade do código executado,
o registro imutável, os ledgers novos e a integração ao coletor devem ser congelados
antes das previsões. Esta entrega não afirma que essa ativação ocorreu.

## Evidência histórica procurada

Foram examinados índices e entradas selecionadas de 16 ZIPs de backup/entrega,
12 revisões de configuração no Git e os arquivos preservados relacionados.
Foram obtidos 27 candidatos de configuração (4 identidades distintas) e 8 cópias
de estados (2 estados distintos). Não houve erros de leitura nessa busca.
Os ZIPs foram consultados seletivamente, sem extração geral e sem ler resultados
das coortes protegidas ou abrir bancos. Configurações privadas não estão neste pacote.

| Lacuna | Resultado desta rodada |
| --- | --- |
| Quatro previsões H15 | Nenhuma combinação adicional de estado/configuração conseguiu reconstruí-las com a proveniência exigida. As tentativas e identidades estão nos recibos. |
| H14 OU2.5 | Ausência de grade/estado e de baseline histórica suficientes. Não é possível identificar OU2.5 apenas com 1X2: previsões certas de 1–0 e de 3–0 têm o mesmo 1X2 e OU opostos. O teste cobre esse contraexemplo. |
| EXP-001 | Os dois nomes de relatórios ausentes não apareceram nos arquivos examinados. Isso não prova inexistência fora do inventário. |
| integrated_xg_v2 / H11 | Não apareceu nova fonte que encerre as lacunas de identidade e ligação histórica já relatadas. |

O suplemento V3 preserva as duas reconstruções anteriores e amplia a rastreabilidade
da busca. Não substitui os originais e não altera sua elegibilidade científica.

## Validade estatística e fontes

O p-value escolhido é uma aproximação por bootstrap, não uma garantia exata de
erro tipo I para toda série temporal. Sua adequação depende das propriedades
da série, inclusive dependência e estacionariedade. Testes de software não
demonstram essas propriedades nos dados reais.
Referência de bootstrap de blocos: Künsch (1989), *The jackknife and the bootstrap
for general stationary observations*, conforme [publicações do autor](https://people.math.ethz.ch/~kuensch/papers/).
O ajuste Holm aceita dependência entre testes, mas requer p-values individuais
adequados; ver [documentação oficial de p.adjust](https://stat.ethz.ch/R-manual/R-devel/library/stats/html/p.adjust.html).
Essas referências fundamentam componentes gerais; não aprovam as escolhas
particulares desta nova especificação nem os dados deste projeto.

## Arquivos e reversão

- `PROTOCOLO_SUCESSOR_V2.json`: especificação completa.
- `BUSCA_HISTORICA_AMPLIADA.json`: arquivos e identidades consultados.
- `H15_SUPLEMENTO_RETROSPECTIVO_V3.json`: suplemento separado, sem resultados reais.
- `RECIBO_PROTOCOLO_V2.json`: hashes, instalação e limites da validação.
- `PROTOCOLO_V2_CODIGO_TESTES_E_EVIDENCIAS.zip`: código, testes e evidências desta rodada.

Código integrado ao checkout em `brasileirao_scripts/prospective_protocol_v2.py`
e à instalação `.venv/Lib/site-packages/brasileirao_scripts/prospective_protocol_v2.py`.
O patch acrescenta esse módulo e atualiza RECORD, sem atualizar dependências.
Backup do RECORD anterior e recibo em
`C:/BRASILEIRAO/work/audit-fixes-20260915/protocol-v2-installation`.
Reversão da instalação, com o aplicativo encerrado:

```powershell
& C:/BRASILEIRAO/brasileirao-predictor/.venv/Scripts/python.exe C:/BRASILEIRAO/work/audit-fixes-20260915/install_protocol_v2.py --rollback
```

A reversão exige hashes iguais aos instalados e mantém o código-fonte entregue.
Os patches da rodada anterior continuam preservados. Não houve publicação Git,
alteração de configuração pessoal ou avaliação dos experimentos protegidos.
'''
(out / 'DADOS_HISTORICOS_E_PROTOCOLO_V2.md').write_text(report, encoding='utf-8')
with (docs / 'prospective_repair_v2_20260915.md').open('x', encoding='utf-8') as stream:
    stream.write(report)
with zipfile.ZipFile(out / 'PROTOCOLO_V2_CODIGO_TESTES_E_EVIDENCIAS.zip', 'w', zipfile.ZIP_DEFLATED) as bundle:
    for name in ('DADOS_HISTORICOS_E_PROTOCOLO_V2.md', 'PROTOCOLO_SUCESSOR_V2.json',
                 'BUSCA_HISTORICA_AMPLIADA.json', 'H15_SUPLEMENTO_RETROSPECTIVO_V3.json', 'RECIBO_PROTOCOLO_V2.json'):
        bundle.write(out / name, name)
    for name in ('brasileirao_scripts/prospective_protocol_v2.py', 'tests/test_prospective_protocol_v2.py'):
        bundle.write(repo / name, 'source/' + name)
    for name in ('expand_recovery.py', 'reconstruct_h15_expanded.py', 'install_protocol_v2.py',
                 'protocol_closeout.py', 'run_protocol_v2_tests.py', 'run_protocol_v2_installed.py',
                 'protocol-v2-tests-01.log', 'protocol-v2-tests-02.log', 'protocol-v2-tests-final.log',
                 'protocol-v2-installed.log', 'protocol-v2-installed-results.xml',
                 'protocol-v2-installation/RECORD.before', 'protocol-v2-installation/receipt.json'):
        bundle.write(base / name, 'evidence/' + name)
with zipfile.ZipFile(out / 'PROTOCOLO_V2_CODIGO_TESTES_E_EVIDENCIAS.zip') as bundle:
    assert bundle.testzip() is None
print(json.dumps({'tests_passed': 155, 'new_tests': 47, 'installed': True,
                  'new_historical_forecasts_recovered': 0, 'preserved_files': len(preserved),
                  'protocol_sha256': protocol.content_hash(spec)}))
