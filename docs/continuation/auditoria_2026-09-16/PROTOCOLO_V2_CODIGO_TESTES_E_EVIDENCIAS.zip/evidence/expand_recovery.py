"""Read only named configs/model states/archive indexes; never outcomes/DBs."""
import hashlib
import json
import subprocess
import zipfile
from pathlib import Path

import yaml

base = Path(__file__).parent / 'expanded-recovery'
base.mkdir(exist_ok=True)
repo = Path('C:/BRASILEIRAO/brasileirao-predictor')
inventory = (base.parent / 'recovery-file-inventory.txt').read_text(encoding='utf-8-sig').splitlines()
targets = {'exp001_data_pilot_2026-09-02.json', 'exp001_coverage_audit_2026-09-02.json',
           'h15_state_control_refit100.json', 'h15_state_treatment_refit10.json'}
configs, states, hits, archives, errors = [], [], [], [], []


def consume(name, data, origin):
    sha = hashlib.sha256(data).hexdigest()
    if name in {'config.yaml', 'config.yml'}:
        cfg = yaml.safe_load(data)
        if not isinstance(cfg, dict) or not {'elo', 'model'} <= cfg.keys():
            return
        if not {'calibration_window_years', 'goal_half_life_days'} <= cfg['model'].keys():
            return
        relevant = {'model_algorithm_version': 'nbdc-normalized-elo-horizon-v2', 'elo': cfg['elo'],
                    'calibration_window_years': cfg['model']['calibration_window_years'],
                    'goal_half_life_days': cfg['model']['goal_half_life_days']}
        if (cfg.get('ensemble_xg') or {}).get('enabled'):
            relevant['ensemble_xg'] = cfg['ensemble_xg']
        configs.append({'path': origin, 'sha256': sha,
                        'config_hash': hashlib.sha256(json.dumps(relevant, sort_keys=True).encode()).hexdigest()[:16],
                        'home_adv': float(cfg['elo']['home_advantage'])})
    elif name.startswith('h15_state_'):
        states.append({'path': origin, 'sha256': sha,
                       'arm': name.removeprefix('h15_state_').removesuffix('.json'),
                       'state': json.loads(data)})
    elif name in targets:
        # Preserve discovery metadata, not protected report contents.
        hits.append({'name': name, 'origin': origin, 'sha256': sha})


for item in inventory:
    p = Path(item)
    if '/externos/' in p.as_posix() or 'site-packages' in p.parts:
        continue
    if p.suffix.lower() == '.zip' and any(part in p.parts for part in ('BACKUPS', 'MIGRACAO_DADOS', 'ENTREGAS')):
        try:
            with zipfile.ZipFile(p) as z:
                matches = []
                for member in z.infolist():
                    name = member.filename.replace('\\', '/').split('/')[-1]
                    if name in targets | {'config.yaml', 'config.yml'} and member.file_size < 2_000_000:
                        if '/externos/' not in member.filename and 'site-packages' not in member.filename:
                            matches.append(member.filename)
                            consume(name, z.read(member), str(p) + '::' + member.filename)
                archives.append({'path': str(p), 'entries': len(z.infolist()), 'matches': matches})
        except (OSError, ValueError, zipfile.BadZipFile, KeyError) as exc:
            errors.append({'path': str(p), 'error': str(exc)})
    elif 'DADOS_PRESERVADOS' in p.parts and p.name in targets | {'config.yaml', 'config.yml'}:
        try:
            consume(p.name, p.read_bytes(), str(p))
        except (ValueError, KeyError, OSError) as exc:
            errors.append({'path': str(p), 'error': str(exc)})

commits = subprocess.check_output(['git', 'log', '--all', '--format=%H', '--', 'config.yaml'], cwd=repo, text=True).splitlines()
for commit in commits:
    result = subprocess.run(['git', 'show', commit + ':config.yaml'], cwd=repo, capture_output=True)
    if result.returncode == 0:
        try:
            consume('config.yaml', result.stdout, 'git:' + commit + ':config.yaml')
        except (ValueError, KeyError) as exc:
            errors.append({'path': commit, 'error': str(exc)})
result = {'configs': configs, 'states': states, 'report_hits': hits, 'archives': archives,
          'git_config_commits_examined': len(commits), 'errors': errors, 'outcomes_read': False}
(base / 'candidates.json').write_text(json.dumps(result, indent=2), encoding='utf-8')
print(json.dumps({'configs': len(configs), 'unique_configs': len({c['config_hash'] for c in configs}),
                  'states': len(states), 'unique_states': len({s['sha256'] for s in states}),
                  'archives': len(archives), 'report_hits': len(hits), 'errors': len(errors)}))
