"""Read forecast schema/lineage only. No outcomes, DB, joins or model imports."""
import hashlib
import json
from pathlib import Path

source = Path('C:/BRASILEIRAO/DADOS_PRESERVADOS/projetos/brasileirao-predictor/data/research')
result = {'scope': 'archived_prediction_schema_only', 'outcomes_read': False, 'files': []}
for filename, arms in [
    ('h14_serving_vs_climatologia.jsonl', ('serving_v2', 'climatology')),
    ('h15_refit10_vs_100.jsonl', ('treatment_refit10', 'control_refit100')),
]:
    path = source / filename
    schemas = set()
    raw = path.read_bytes()
    # These dedicated append-only schemas were inspected in producer source;
    # generic prediction stores and any result/settlement files are excluded.
    for line in raw.decode('utf-8-sig').splitlines():
        if not line.strip():
            continue
        row = json.loads(line)
        schema = {'top_level_keys': sorted(row), 'arm_keys': {arm: sorted(row.get(arm, {})) for arm in arms}}
        schemas.add(json.dumps(schema, sort_keys=True))
    result['files'].append({'path': str(path), 'sha256': hashlib.sha256(raw).hexdigest(),
                            'schemas': [json.loads(item) for item in sorted(schemas)]})
for filename in ('h15_state_control_refit100.json', 'h15_state_treatment_refit10.json'):
    path = source / filename
    raw = path.read_bytes()
    row = json.loads(raw)
    result['files'].append({'path': str(path), 'sha256': hashlib.sha256(raw).hexdigest(),
                            'top_level_keys': sorted(row), 'refit_at': row.get('refit_at'),
                            'limitation': 'single current state; not proof of every original forecast state'})
out = Path('C:/Users/leona/Documents/Codex/2026-09-15/lea/outputs/RECUPERACAO_PREVISOES_METADATA.json')
out.write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
print(json.dumps(result, ensure_ascii=False, indent=2))
