"""Retrospective supplemental OU probabilities; never a prospective repair.

No outcomes, fitting, evaluator, DB, network or provider are used. Originals
are immutable. A matching state, design fingerprint and exact rounded 1X2
reproduction are prerequisites; unmatched arms remain missing.
"""
import hashlib
import json
import os
import platform
import sys
from datetime import datetime
from pathlib import Path

base = Path(__file__).resolve().parent
root = base / 'forecast-recovery'
source = Path('C:/BRASILEIRAO/DADOS_PRESERVADOS/projetos/brasileirao-predictor')
sys.dont_write_bytecode = True
sys.path.insert(0, str(base / 'candidate'))
import yaml

cfg_bytes = (source / 'config.yaml').read_bytes()
cfg = yaml.safe_load(cfg_bytes)
cfg_hash = hashlib.sha256(cfg_bytes).hexdigest()
relevant = {'model_algorithm_version': 'nbdc-normalized-elo-horizon-v2', 'elo': cfg['elo'],
            'calibration_window_years': cfg['model']['calibration_window_years'],
            'goal_half_life_days': cfg['model']['goal_half_life_days']}
if (cfg.get('ensemble_xg') or {}).get('enabled'):
    relevant['ensemble_xg'] = cfg['ensemble_xg']
hash_value = hashlib.sha256(json.dumps(relevant, sort_keys=True).encode()).hexdigest()[:16]
home_adv = float(cfg['elo']['home_advantage'])
states, state_hashes = {}, {}
for arm in ('control_refit100', 'treatment_refit10'):
    path = source / f'data/research/h15_state_{arm}.json'
    raw = path.read_bytes()
    states[arm] = json.loads(raw)
    state_hashes[arm] = hashlib.sha256(raw).hexdigest()
    copy_path = root / 'originals' / path.name
    if copy_path.exists():
        assert copy_path.read_bytes() == raw
    else:
        with copy_path.open('xb') as stream:
            stream.write(raw)


def audit(event, args):
    if event.startswith('socket.') or event in {'subprocess.Popen', 'os.system', 'sqlite3.connect'}:
        raise RuntimeError('Reconstruction forbids network, processes and databases')
    if event == 'open' and isinstance(args[0], (str, bytes, os.PathLike)):
        path = Path(os.fsdecode(args[0])).resolve()
        if path.is_relative_to(source):
            raise RuntimeError('No further archive access after freezing inputs')
        mode, flags = args[1:3]
        writing = (isinstance(mode, str) and any(c in mode for c in 'wax+')) or (
            isinstance(flags, int) and flags & (os.O_WRONLY | os.O_RDWR | os.O_CREAT | os.O_TRUNC))
        if writing and not path.is_relative_to(root):
            raise RuntimeError('Output must remain in isolated recovery directory')


platform.uname()  # Resolve OS metadata before network/subprocess prohibition.
sys.addaudithook(audit)
from brasileirao_predictor import model

original = root / 'originals/h15_refit10_vs_100.jsonl'
before = hashlib.sha256(original.read_bytes()).hexdigest()
records = [json.loads(line) for line in original.read_text(encoding='utf-8').splitlines() if line.strip()]
out = {'classification': 'RETROSPECTIVE_RECONSTRUCTION_NOT_ORIGINAL_FORECAST',
       'original_sha256': before, 'config_source_sha256': cfg_hash, 'config_fingerprint': hash_value,
       'model_source_sha256': hashlib.sha256(Path(model.__file__).read_bytes()).hexdigest(),
       'original_code_identity_proven': False, 'outcomes_used': False, 'training_executed': False,
       'prospective_eligibility_restored': False, 'capital_enabled': False, 'records': []}
for row in records:
    item = {'event_id': row['event_id'], 'predicted_at': row['predicted_at'], 'arms': {}}
    for arm, cadence in (('control_refit100', 100), ('treatment_refit10', 10)):
        state, old = states[arm], row[arm]
        result = {'state_sha256': state_hashes[arm], 'status': 'UNRECOVERED', 'p_over_2_5': None}
        policy = {'trial': 'h15-refit10-vs-100-serving-v2-prospectivo', 'arm': arm,
                  'retrain_every': cadence, 'algorithm_version': 'nbdc-normalized-elo-horizon-v2',
                  'config_hash': hash_value, 'home_advantage': home_adv}
        fingerprint = hashlib.sha256(json.dumps(policy, sort_keys=True).encode()).hexdigest()[:16]
        if old['refit_at'] != state['refit_at']:
            result['reason'] = 'HISTORICAL_STATE_NOT_LOCATED'
        elif old['code_fingerprint'] != fingerprint:
            result['reason'] = 'DESIGN_FINGERPRINT_MISMATCH'
        elif not (datetime.fromisoformat(state['refit_at']) <= datetime.fromisoformat(row['predicted_at'])
                  < datetime.fromisoformat(row['kickoff_at'])):
            result['reason'] = 'TEMPORAL_PROVENANCE_MISMATCH'
        else:
            prediction = model.predict_match(state['elo'][row['home']], state['elo'][row['away']],
                                             tuple(state['params']), home_adv)
            checks = {'p_home': 'p_win', 'p_draw': 'p_draw', 'p_away': 'p_loss'}
            if not all(round(prediction[new], 6) == old[key] for key, new in checks.items()):
                result['reason'] = 'ORIGINAL_1X2_NOT_REPRODUCED'
            else:
                result.update(status='RECONSTRUCTED_RETROSPECTIVE', reason='MATCHING_STATE_DESIGN_AND_ROUNDED_1X2',
                              p_over_2_5=float(prediction['over'][2.5]))
        item['arms'][arm] = result
    out['records'].append(item)
assert hashlib.sha256(original.read_bytes()).hexdigest() == before
with (root / 'h15-retrospective-supplement.json').open('x', encoding='utf-8') as stream:
    json.dump(out, stream, ensure_ascii=False, indent=2, allow_nan=False)
counts = {}
for row in out['records']:
    for arm in row['arms'].values():
        counts[arm['reason']] = counts.get(arm['reason'], 0) + 1
print(json.dumps({'supplement': str(root / 'h15-retrospective-supplement.json'), 'reasons': counts,
                  'original_preserved': True, 'outcomes_used': False}))
