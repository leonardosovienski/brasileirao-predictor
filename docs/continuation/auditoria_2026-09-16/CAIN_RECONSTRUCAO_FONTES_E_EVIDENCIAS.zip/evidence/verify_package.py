"""Installed CAIN, isolated database and identity; no LLM/network necessary."""
import json
import sys
from pathlib import Path

sys.dont_write_bytecode = True
from research_snapshot import canonical, validate
from cain.research import ResearchService
from cain.research.analysis import review
from cain.research.inspection import inspect
from build_package import BASE, SOURCE, REPOSITORY, PUBLISHER, STREAM, POLICY, cell


class NoGeneration:
    base_url = 'http://127.0.0.1:11439'

    def generate_json(self, *args):
        raise AssertionError('Curated literal evidence must not require generated facts')


def grant(user, source=SOURCE):
    return {'user': user, 'project': '', 'collection': 'brasileirao', 'domain': 'brasileirao',
            'repository': REPOSITORY, 'publisher': PUBLISHER, 'stream': STREAM,
            'sources': [source], 'policies': [POLICY], 'generate': True}


def main():
    root = BASE / sys.argv[1]
    root.mkdir(exist_ok=False)
    manifest = json.loads((BASE / ('manifest-annex.json' if '--annex' in sys.argv else 'manifest.json')).read_text(encoding='utf-8'))
    policy = {'version': 1, 'import_root': str(BASE / 'publications'), 'grants': [grant('qa-br-reconstruction', manifest['source'])]}
    policy_path = root / 'policy.json'
    policy_path.write_bytes(canonical(policy))
    service = ResearchService(root / 'research.db', policy_path)
    scope = service.scope('qa-br-reconstruction', collection='brasileirao')
    receipts = []
    for pubid in manifest['packages']:
        validate(json.loads((BASE / 'publications' / (pubid + '.json')).read_bytes()))
        result = service.ingest(pubid + '.json', scope)
        assert result['status'] == 'admitted', result
        receipts.append(result)
    dossier = inspect(service, scope)
    assert len(dossier['records']) == manifest['record_count']
    results, failures = [], []
    for row in manifest['records']:
        try:
            result = review(service, scope, 'O que a fonte registra sobre ' + row['id'] + '?',
                            NoGeneration(), role='synthesis', source_id=row['id'])
            text = result.get('explanation', {}).get('proposed_synthesis', '')
            assert result['status'] == 'literal_claim_table', result.get('status')
            assert result['model_calls'] == 0
            for label, value in row['fields'].items():
                assert cell(value) in text, f'Missing literal field {label}'
            assert result['explanation']['source_quotes']
            results.append({'id': row['id'], 'status': result['status'], 'answer': text,
                            'fields_verified': len(row['fields']), 'model_calls': 0})
        except Exception as exc:
            failures.append({'id': row['id'], 'error': str(exc)})
    before = len(dossier['records'])
    for pubid in manifest['packages']:
        assert service.ingest(pubid + '.json', scope)['status'] == 'duplicate'
    assert len(inspect(service, scope)['records']) == before
    forecast_rows = [r for r in manifest['records'] if 'OU2.5 original' in r['fields']]
    if '--annex' not in sys.argv:
        assert len(forecast_rows) == 12
        assert sum(r['state'] == 'RETROSPECTIVE_RECONSTRUCTION' for r in forecast_rows) == 2
        assert all(r['fields']['OU2.5 original'] == 'AUSENTE' for r in forecast_rows)
        assert sum(r['fields']['OU2.5 reconstruído'] == 'NÃO RECUPERADO' for r in forecast_rows) == 10
    report = {'installed_cain': __import__('cain').__file__, 'admission_receipts': receipts,
              'records_admitted': manifest['record_count'], 'literal_queries_passed': len(results), 'failures': failures,
              'idempotency_passed': True, 'forecast_classifications_passed': True,
              'model_calls': 0, 'results': results}
    (root / 'verification.json').write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding='utf-8')
    print(json.dumps({k: v for k, v in report.items() if k != 'results'}, ensure_ascii=False))
    if failures:
        raise SystemExit(1)


if __name__ == '__main__':
    main()
