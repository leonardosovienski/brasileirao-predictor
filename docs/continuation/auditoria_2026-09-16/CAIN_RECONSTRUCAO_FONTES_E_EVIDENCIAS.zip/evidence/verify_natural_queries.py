import json
import sys

sys.dont_write_bytecode = True
from cain.research import ResearchService
from cain.research.analysis import review
from build_package import BASE
from verify_package import NoGeneration

service = ResearchService('C:/CAIN/dados/research.db', 'C:/CAIN/config/research-policy.json')
scope = service.scope('leo', collection='brasileirao')
cases = [
    ('Quais dados históricos ainda faltam?', ['BR-AUDIT-DADOS-HISTORICOS-FALTANTES', '6 OU2.5 H14', '4 OU2.5 H15']),
    ('O que foi recuperado das previsões H15?', ['2 de 6', 'não restauram elegibilidade prospectiva']),
    ('O protocolo BR-AUDIT-PROTOCOLO-V2 já está ativado?', ['NÃO ATIVADA', 'NÃO EFETUADA']),
    ('Qual baseline está definida no BR-AUDIT-PROTOCOLO-DETALHE-3?', ['Beta(1,1)', '200', 'preceding calendar date']),
    ('O que falta no BR-AUDIT-FALTA-EXP001-PILOT?', ['exp001_data_pilot_2026-09-02.json', 'Ausente']),
    ('Os relatórios complementares substituem os originais ausentes?', ['não substitui originais ausentes']),
]
results = []
for question, required in cases:
    try:
        response = review(service, scope, question, NoGeneration(), role='synthesis')
        answer = response.get('explanation', {}).get('proposed_synthesis', '')
        missing = [text for text in required if text not in answer]
        passed = response['status'] == 'literal_claim_table' and response['model_calls'] == 0 and not missing
        results.append({'question': question, 'passed': passed, 'missing': missing,
                        'status': response['status'], 'answer': answer, 'model_calls': response['model_calls']})
    except Exception as exc:
        results.append({'question': question, 'passed': False, 'error': str(exc)})
(BASE / 'natural-queries-final.json').write_text(json.dumps(results, ensure_ascii=False, indent=2), encoding='utf-8')
print(json.dumps({'passed': sum(r['passed'] for r in results), 'total': len(results),
                  'failures': [r for r in results if not r['passed']]}, ensure_ascii=False))
raise SystemExit(0 if all(r['passed'] for r in results) else 1)
