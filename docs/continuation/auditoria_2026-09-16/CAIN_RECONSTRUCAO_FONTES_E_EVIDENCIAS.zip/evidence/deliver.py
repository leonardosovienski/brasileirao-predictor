import json
import shutil
import zipfile
from pathlib import Path

from research_snapshot import digest
from build_package import BASE, OUT

admissions = [json.loads((BASE / name).read_text(encoding='utf-8'))
              for name in ('primary-admission.json', 'primary-admission-annex.json')]
manifests = [json.loads((BASE / name).read_text(encoding='utf-8'))
             for name in ('manifest.json', 'manifest-annex.json')]
queries = json.loads((BASE / 'natural-queries-final.json').read_text(encoding='utf-8'))
assert all(q['passed'] for q in queries)
assert sum(a['new_records'] for a in admissions) == 82
assert all(a['all_preexisting_database_rows_preserved'] for a in admissions)
for path, expected in manifests[0]['original_hashes'].items():
    assert digest(Path(path).read_bytes()) == expected
have = '''# O que está disponível para o CAIN

Coleção principal: `brasileirao`, usuário `leo`. Banco: `C:/CAIN/dados/research.db`.
Foram acrescentados 82 registros auditados; a coleção possui 85 registros,
incluindo os três anteriores. Registros e revisões não equivalem a hipóteses independentes.

| Material | Disponibilidade e limite |
| --- | --- |
| Trials | 29 entradas documentais com IDs, estados originais, avaliação documental e evidência mínima faltante. Não reexecutadas. |
| Claims de mercado | Três claims separadas, H-24h/H-6h/H-1h; bloqueios e ressalvas preservados. |
| Previsões antigas | 12 previsões por braço 1X2 preservadas, seis H14 e seis H15. |
| OU2.5 H15 | Duas reconstruções retrospectivas, com proveniência e limitações. Não são previsões originais. |
| Relatórios complementares EXP-001 | Três documentos obtidos do GitHub e integralmente representados por campos nos registros do CAIN. |
| Protocolo sucessor | Todos os campos da especificação disponíveis; biblioteca instalada. Coleta e inscrição canônica ainda não ativadas. |
| Inventário das lacunas | Registro específico BR-AUDIT-DADOS-HISTORICOS-FALTANTES, além dos registros individuais. |

Os três documentos complementares são:

- `exp001_coverage_identity_assessment_2026-09-02.json`
- `exp001_feature_pit_audit_2026-09-02.json`
- `exp001_readiness_decision_2026-09-02.json`

Eles são históricos, de 02/09/2026. A cobertura antiga declarada de 245/245 não
prova validade no cutoff, nem disponibilidade temporal de todas as features.
Não substituem os dois relatórios originais que permanecem ausentes.

Perguntas verificadas no CAIN:

- “Quais dados históricos ainda faltam?”
- “O que foi recuperado das previsões H15?”
- “O protocolo BR-AUDIT-PROTOCOLO-V2 já está ativado?”
- “Qual baseline está definida no BR-AUDIT-PROTOCOLO-DETALHE-3?”
- “O que falta no BR-AUDIT-FALTA-EXP001-PILOT?”
- “Os relatórios complementares substituem os originais ausentes?”
'''
missing = '''# O que falta e o que foi feito para obter

| Item faltante | Busca/recuperação efetuada | Situação e fonte necessária |
| --- | --- | --- |
| Seis probabilidades OU2.5 históricas H14 | Originais, arquivos preservados, backups, configurações, Git remoto e metadados de cache de modelo | Não recuperadas. São necessários grade/estado histórico e baseline definida à época. 1X2 sozinho não identifica OU2.5. |
| Quatro probabilidades OU2.5 históricas H15 | 27 candidatos de configuração, oito cópias de estados, 16 ZIPs e 12 revisões de configuração, além do Git remoto atualizado | Nenhuma combinação adicional satisfez toda a proveniência. Continuam 2/6 reconstruídas e 4/6 não recuperadas. |
| exp001_data_pilot_2026-09-02.json | Arquivos locais, índices de backups, histórico local e histórico do repositório remoto atualizado | Não localizado. Código do produtor existe, mas reexecutá-lo hoje não recria o relatório original nem os timestamps de 2026-09-02. |
| exp001_coverage_audit_2026-09-02.json | Mesma busca; três relatórios complementares obtidos e entregues ao CAIN | Original não localizado. Complementos permanecem identificados como complementos. |
| Timestamps históricos PIT | Relatório complementar completo de auditoria temporal agora disponível ao CAIN | São necessários recibos/publicações originais do provedor. Kickoff, horário de coleta atual e placar final não substituem publicação histórica. |
| integrated_xg_v2 / ligação H11 | Inventário e referências documentais/Git consultados | Identidade e ligação ainda não comprovadas; não fundir modelos ou hipóteses pelo nome. |

O repositório remoto foi consultado em `460a397adc2f0dbe11ed6bda83aa9a8009d04549`.
Os caminhos offsite citados nos documentos históricos, sob os perfis Superleo13
e leona/OneDrive/Codex-Offsite, não existem nos caminhos locais conferidos.
Não foi estabelecido acesso à conta remota desse armazenamento.
O cache do snapshot de matches inspecionado tem `computed_at=2026-09-08T14:05:40+00:00`,
posterior às previsões do recorte; não foi usado para simular um estado anterior.
Nessa inspeção só foram consultados esquema e cache de parâmetros, sem tabelas de resultados.

Ausência nas fontes examinadas não prova inexistência global. O CAIN deve informar
essas lacunas, sem preencher números, timestamps ou identidades como se fossem fatos.
Nenhuma avaliação protegida foi executada e nenhum resultado de jogo foi adquirido
para aparentar reconstrução da previsão que deveria existir antes dele.
'''
report = '''# Entrega ao CAIN — inventário, fontes e reconstruções

## Entrega operacional

O material foi efetivamente admitido na coleção principal `brasileirao` do usuário
`leo`: **82 registros novos, 85 no total**. Não ficou apenas nos relatórios de QA.
Foram adicionadas duas autorizações exatas para as duas fontes derivadas desta
auditoria. Permissões anteriores e demais coleções permaneceram preservadas.

Consulte `CAIN_O_QUE_TEM.md` e `CAIN_O_QUE_FALTA.md` para a separação solicitada.
As fontes complementares obtidas estão na pasta `FONTES_COMPLEMENTARES_EXP001`.

## Verificação

- Admissão e leitura no CAIN instalado, primeiro em QA isolado e depois na coleção principal.
- 82 consultas por registro confirmaram todos os campos literais, estados e ressalvas.
- Seis perguntas gerais passaram após a inclusão de um índice específico das lacunas.
- Nenhuma dessas respostas exigiu geração de fatos pelo modelo; usaram o caminho literal validado.
- Admissão repetida testada em QA sem duplicar registros.
- Banco SQLite com `integrity_check=ok`.
- Todos os registros anteriores do banco foram preservados, comparados por hashes de linhas.
- Hashes das fontes de reconstrução/originais conferidos antes e depois.

Uma primeira versão do anexo falhou em quatro consultas: um cabeçalho duplicava
ID/id e três tabelas ultrapassavam o limite aceito por linha. Os cabeçalhos foram
qualificados e os campos foram divididos em blocos menores, mantendo todo o conteúdo.
O anexo corrigido passou 26/26 consultas antes da admissão principal. A tentativa
reprovada foi preservada em QA e não foi admitida na coleção principal.

## Limite real

O conteúdo disponível e as lacunas estão preparados para consulta rastreável no
CAIN. Isso não significa que os arquivos históricos ausentes apareceram: continuam
2/6 braços H15 reconstruídos, nenhuma reconstrução H14 e dois relatórios originais
ausentes. Os três documentos obtidos são complementares, não substitutos.
Não se afirma perfeição universal do CAIN, de toda pergunta livre ou dos modelos.

## Preservação e rastreabilidade

Recibos: `CAIN_RECIBO_ADMISSAO.json` e `CAIN_PERGUNTAS_VERIFICADAS.json`.
Backups consistentes do banco e da política anteriores às duas admissões, mantidos
somente localmente por conterem material privado:

- `C:/CAIN/work/brasileirao-reconstruction-20260915/primary-backup`
- `C:/CAIN/work/brasileirao-reconstruction-20260915/primary-backup-annex`

Esses bancos privados não integram o ZIP de entrega. Não restaurar um banco antigo
sobre novas conversas/admissões. Se for necessário ocultar esse material, remover
somente as duas autorizações do stream `reconstruction-audit` para as fontes
`local-audit/brasileirao-reconstruction-20260915.md` e
`local-audit/brasileirao-reconstruction-details-20260915.md`, preservando os arquivos
de evidência e as demais autorizações. Nenhum código ou dado foi publicado no Git.
'''
for name, text in [('CAIN_O_QUE_TEM.md', have), ('CAIN_O_QUE_FALTA.md', missing), ('CAIN_ENTREGA_RECONSTRUCAO.md', report)]:
    (OUT / name).write_text(text, encoding='utf-8')
receipt = {'admissions': admissions, 'new_records': 82, 'primary_records_total': 85,
           'verified_per_record_queries': 82, 'natural_language_cases_passed': 6,
           'remote_head': manifests[0]['remote_head'], 'original_hashes': manifests[0]['original_hashes'],
           'original_ou_forecasts_recovered': 0, 'retrospective_ou_reconstructions': 2,
           'unrecovered_ou_arm_forecasts': 10, 'complementary_reports_obtained': 3,
           'unrecovered_original_reports': 2, 'all_bugs_absence_certified': False}
(OUT / 'CAIN_RECIBO_ADMISSAO.json').write_text(json.dumps(receipt, ensure_ascii=False, indent=2), encoding='utf-8')
shutil.copyfile(BASE / 'natural-queries-final.json', OUT / 'CAIN_PERGUNTAS_VERIFICADAS.json')
sources = OUT / 'FONTES_COMPLEMENTARES_EXP001'
sources.mkdir(exist_ok=True)
for path in (BASE / 'recovered-public').glob('*.json'):
    shutil.copyfile(path, sources / path.name)
with zipfile.ZipFile(OUT / 'CAIN_RECONSTRUCAO_FONTES_E_EVIDENCIAS.zip', 'w', zipfile.ZIP_DEFLATED) as archive:
    for name in ['CAIN_O_QUE_TEM.md', 'CAIN_O_QUE_FALTA.md', 'CAIN_ENTREGA_RECONSTRUCAO.md',
                 'CAIN_RECIBO_ADMISSAO.json', 'CAIN_PERGUNTAS_VERIFICADAS.json']:
        archive.write(OUT / name, name)
    for name in ['build_package.py', 'build_annex.py', 'verify_package.py', 'admit_primary.py',
                 'verify_natural_queries.py', 'deliver.py', 'manifest.json', 'manifest-annex.json',
                 'manifest-annex-before-correction.json', 'qa-01/verification.json',
                 'qa-annex/verification.json', 'qa-annex2/verification.json',
                 'BRASILEIRAO_O_QUE_TEM_E_FALTA.md', 'BRASILEIRAO_DETALHES_E_FONTES.md']:
        archive.write(BASE / name, 'evidence/' + name)
    for manifest in manifests:
        for pubid in manifest['packages']:
            archive.write(BASE / 'publications' / (pubid + '.json'), 'publications/' + pubid + '.json')
    for path in sources.glob('*.json'):
        archive.write(path, 'sources/' + path.name)
with zipfile.ZipFile(OUT / 'CAIN_RECONSTRUCAO_FONTES_E_EVIDENCIAS.zip') as archive:
    assert archive.testzip() is None
print(json.dumps({'delivered': True, 'primary_new_records': 82, 'verified_queries': 88,
                  'missing_originals_not_fabricated': True}))
