"""Add a discovery index and full technical/document fields to the CAIN source set."""
import json
import math
from datetime import datetime, timezone

from research_snapshot import canonical, digest, seal, validate
from build_package import BASE, OUT, REPOSITORY, PUBLISHER, STREAM, POLICY, cell

source = 'local-audit/brasileirao-reconstruction-details-20260915.md'
rows = []


def add(identity, description, fields):
    def flatten(key, value):
        if len(cell(value)) > 350 and isinstance(value, (dict, list)):
            items = value.items() if isinstance(value, dict) else enumerate(value)
            for child, item in items:
                yield from flatten(key + '/' + str(child), item)
        else:
            yield key, value
    parts, current = [], {}
    fixed = {'ID': identity + '-P99', 'Hipótese': description, 'Estado': 'DOCUMENTARY_DETAIL'}
    for key, value in fields.items():
        for label, item in flatten(key, value):
            candidate = {**fixed, **current, label: item}
            if len('| ' + ' | '.join(cell(v) for v in candidate.values()) + ' |') > 950 and current:
                parts.append(current)
                current = {}
            current[label] = item
    if current:
        parts.append(current)
    for index, part in enumerate(parts, 1):
        actual_id = identity if len(parts) == 1 else identity + '-P' + str(index)
        columns = {'ID': actual_id, 'Hipótese': description, 'Estado': 'DOCUMENTARY_DETAIL', **part}
        line = '| ' + ' | '.join(cell(v) for v in columns.values()) + ' |\n'
        assert len(line.strip()) <= 1000, actual_id
        text = ('| ' + ' | '.join(columns) + ' |\n| ' + ' | '.join('---' for _ in columns) + ' |\n' + line)
        rows.append({'id': actual_id, 'state': 'DOCUMENTARY_DETAIL', 'fields': columns, 'text': text})


add('BR-AUDIT-DADOS-HISTORICOS-FALTANTES', 'Dados históricos faltantes: quais dados históricos ainda faltam e quais existem', {
    'Disponível': '29 entradas de trials, 3 claims, 12 previsões 1X2 originais, 2 OU2.5 H15 reconstruídos, 3 relatórios complementares obtidos',
    'Ainda falta': '6 OU2.5 H14; 4 OU2.5 H15; 2 relatórios originais EXP-001; identidade integrated_xg_v2; ligação H11; timestamps históricos PIT',
    'Relatórios originais ausentes': 'exp001_data_pilot_2026-09-02.json e exp001_coverage_audit_2026-09-02.json',
    'Reconstrução': '2 de 6 braços H15 e 0 de 6 H14; nenhum OU2.5 original registrado; originais preservados',
    'Limite': 'Ausente nas fontes consultadas; não declarar inexistência global nem imputar informação como observada',
})
protocol = json.loads((OUT / 'PROTOCOLO_SUCESSOR_V2.json').read_text(encoding='utf-8'))
groups = [
    ['id', 'family', 'status', 'legacy_cohorts_eligible', 'reconstructions_eligible', 'capital_enabled', 'activation'],
    ['minimum_sample_per_member', 'intermediate_evaluations', 'evaluation_order', 'cohort', 'prediction_window_hours', 'model', 'h15_refit_games'],
    ['h14_baseline', 'required_escrow'],
    ['metrics', 'one_x_two_order', 'rps', 'log_loss', 'brier_1x2', 'brier_ou25', 'gain'],
    ['bootstrap', 'decision'],
]
assert {key for group in groups for key in group} == set(protocol)
for index, keys in enumerate(groups, 1):
    add(f'BR-AUDIT-PROTOCOLO-DETALHE-{index}', 'Protocolo sucessor: definições completas; ainda não ativado',
        {'Regra: ' + key: protocol[key] for key in keys})
for path in sorted((BASE / 'recovered-public').glob('*.json')):
    raw = path.read_bytes()
    items = list(json.loads(raw).items())
    short = path.stem.removeprefix('exp001_').removesuffix('_2026-09-02').upper().replace('_', '-')
    for offset in range(0, len(items), 2):
        add(f'BR-AUDIT-DOC-{short}-{offset // 2 + 1}',
            f'Relatório complementar histórico de 2026-09-02; bloco {offset // 2 + 1} de {math.ceil(len(items) / 2)}',
            {'Arquivo': path.name, **dict(items[offset:offset+2]),
             'Ressalva da auditoria': 'Estado declarado em 2026-09-02; cobertura antiga não prova validade no cutoff; não substitui originais ausentes',
             'SHA256 do documento completo': digest(raw)})
text, evidence, records = '', [], []
for row in rows:
    start = len(text)
    text += row['text'] + '\n'
    eid = digest(row['text'].encode())
    evidence.append({'id': eid, 'source': source, 'availability': 'received', 'text': row['text'],
                     'sha256': eid, 'hash_basis': 'received_utf8', 'locator': f'characters:{start}:{start+len(row["text"])}',
                     'start': start, 'end': start + len(row['text']), 'offset_unit': 'unicode_codepoints'})
    records.append({'source_id': row['id'], 'revision': eid, 'kind': 'audit_reconstruction_detail',
                    'identity_basis': 'source_assigned', 'source_status': row['state'], 'status_axis': 'source_availability',
                    'mapping': None, 'reason': None, 'event_at': None, 'recorded_at': None, 'available_at': None,
                    'supersedes': [], 'evidence_ids': [eid]})
original = json.loads((BASE / 'manifest.json').read_text(encoding='utf-8'))
package = validate(seal({
    'contract': 'ResearchSnapshotV1', 'profile': 'local-evidence/1', 'extensions': {},
    'origin': {'domain': 'brasileirao', 'repository': REPOSITORY, 'publisher': PUBLISHER, 'stream': STREAM,
               'code_revision': original['remote_head'], 'exporter_revision': 'br-audit-reconstruction-details/1',
               'inputs': {source: digest(text.encode())}},
    'exported_at': datetime.now(timezone.utc).isoformat(),
    'restrictions': {'policy': POLICY, 'read': True, 'disclose': False, 'generate': True},
    'coverage': {'scope': 'Full fields of three complementary documents and successor protocol; gap discovery index',
                 'completeness': 'partial', 'included': [source], 'missing': ['unrecovered historical originals'],
                 'excluded': ['protected cohort outcomes', 'private configuration'],
                 'limitations': ['Derived local curation', 'Historical statuses are not current truth', 'No scientific re-evaluation']},
    'records': records, 'evidence': evidence}))
(BASE / 'publications' / (package['publication_id'] + '.json')).write_bytes(canonical(package))
(BASE / 'BRASILEIRAO_DETALHES_E_FONTES.md').write_text(text, encoding='utf-8')
manifest = {'records': rows, 'packages': [package['publication_id']], 'record_count': len(rows),
            'source': source, 'original_hashes': original['original_hashes'], 'source_sha256': digest(text.encode())}
(BASE / 'manifest-annex.json').write_text(json.dumps(manifest, ensure_ascii=False, indent=2), encoding='utf-8')
print(json.dumps({'annex_records': len(rows), 'full_report_fields': True, 'full_protocol_fields': True}))
