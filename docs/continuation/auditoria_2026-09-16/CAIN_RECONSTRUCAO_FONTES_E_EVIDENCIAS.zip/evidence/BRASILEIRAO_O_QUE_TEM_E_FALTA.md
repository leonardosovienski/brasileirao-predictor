| ID | Hipótese | Estado | O que tem | O que falta | Distinção | Limites | Avaliação científica |
| --- | --- | --- | --- | --- | --- | --- | --- |
| BR-AUDIT-RESUMO | Inventário documental e recuperação histórica | PARTIAL_RECOVERY | 29 entradas de trials; 3 claims; 12 previsões por braço originais; 2 OU2.5 retrospectivos H15 | OU2.5 não recuperável em 10 braços; 2 relatórios EXP-001 originais ausentes; OU2.5 original ausente em todos os 12 braços | 2 de 6 braços H15 reconstruídos; 0 de 6 braços H14; nenhum OU2.5 foi registrado originalmente | As 2 reconstruções não são previsões originais e não restauram elegibilidade prospectiva | Nenhuma nesta auditoria; testes de software não demonstram ganho preditivo |

| ID | Hipótese | Estado | ID original | Estado original | Data registrada | Avaliação documental | Próxima evidência necessária | Fonte | Limite |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| BR-AUDIT-TRIAL-01 | Entrada documental: h1-ou25-edge-2-15-walkforward | DOCUMENTARY_RECORD | h1-ou25-edge-2-15-walkforward | refutada | 2026-07-11T00:55:18Z | Backtest retrospectivo declarado; n=455, ROI +7,9%, IC inclui zero, DSR 0,94; regra de GO não satisfeita | Recuperar painel/preços e convenções antes de eventual reprodução | data/trials.json#name=h1-ou25-edge-2-15-walkforward | Não reexecutado; variantes não são hipóteses independentes |

| ID | Hipótese | Estado | ID original | Estado original | Data registrada | Avaliação documental | Próxima evidência necessária | Fonte | Limite |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| BR-AUDIT-TRIAL-02 | Entrada documental: h2-periodo-1t-conf60 | DOCUMENTARY_RECORD | h2-periodo-1t-conf60 | informativa | 2026-07-11T00:55:18Z | Avaliação histórica n=1493; acurácia ~79%; não demonstra retorno sem preços | Demonstrar elegibilidade temporal dos preços para uma claim econômica | data/trials.json#name=h2-periodo-1t-conf60 | Não reexecutado; variantes não são hipóteses independentes |

| ID | Hipótese | Estado | ID original | Estado original | Data registrada | Avaliação documental | Próxima evidência necessária | Fonte | Limite |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| BR-AUDIT-TRIAL-03 | Entrada documental: h3-ou25-sombra-2026 | DOCUMENTARY_RECORD | h3-ou25-sombra-2026 | substituida | 2026-07-11T05:55:57Z | Configuração antiga de shadow substituída | Preservar relação de supersessão, sem reativar | data/trials.json#name=h3-ou25-sombra-2026 | Não reexecutado; variantes não são hipóteses independentes |

| ID | Hipótese | Estado | ID original | Estado original | Data registrada | Avaliação documental | Próxima evidência necessária | Fonte | Limite |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| BR-AUDIT-TRIAL-04 | Entrada documental: H4_DIXON_COLES_CALIBRATED | DOCUMENTARY_RECORD | H4_DIXON_COLES_CALIBRATED | refutada | 2026-07-12T01:50:24Z | Histórico n=737; ganho RPS 0,00235, IC [-0,00216; 0,00684]; superioridade não demonstrada | Recuperar trilha das seis variantes antes de nova alegação | data/trials.json#name=H4_DIXON_COLES_CALIBRATED | Não reexecutado; variantes não são hipóteses independentes |

| ID | Hipótese | Estado | ID original | Estado original | Data registrada | Avaliação documental | Próxima evidência necessária | Fonte | Limite |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| BR-AUDIT-TRIAL-05 | Entrada documental: h5-ensemble-xg-sombra-2026 | DOCUMENTARY_RECORD | h5-ensemble-xg-sombra-2026 | substituida | 2026-07-17T04:01:36Z | Shadow antigo substituído | Resolver versão/preços, sem transferir desempenho | data/trials.json#name=h5-ensemble-xg-sombra-2026 | Não reexecutado; variantes não são hipóteses independentes |

| ID | Hipótese | Estado | ID original | Estado original | Data registrada | Avaliação documental | Próxima evidência necessária | Fonte | Limite |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| BR-AUDIT-TRIAL-06 | Entrada documental: h3-ou25-sombra-pinnacle-2026 | DOCUMENTARY_RECORD | h3-ou25-sombra-pinnacle-2026 | inconclusiva | 2026-07-26T00:28:58Z | Shadow documentado; encerramento/limites operacionais não equivalem a refutação | Reconciliar recibos históricos já liberados | data/trials.json#name=h3-ou25-sombra-pinnacle-2026 | Não reexecutado; variantes não são hipóteses independentes |

| ID | Hipótese | Estado | ID original | Estado original | Data registrada | Avaliação documental | Próxima evidência necessária | Fonte | Limite |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| BR-AUDIT-TRIAL-07 | Entrada documental: h5-ensemble-xg-sombra-pinnacle-2026 | DOCUMENTARY_RECORD | h5-ensemble-xg-sombra-pinnacle-2026 | inconclusiva | 2026-07-26T00:28:58Z | Ensemble shadow, suporte insuficiente para conclusão econômica | Reconciliar versão e denominadores históricos | data/trials.json#name=h5-ensemble-xg-sombra-pinnacle-2026 | Não reexecutado; variantes não são hipóteses independentes |

| ID | Hipótese | Estado | ID original | Estado original | Data registrada | Avaliação documental | Próxima evidência necessária | Fonte | Limite |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| BR-AUDIT-TRIAL-08 | Entrada documental: h1-ou25-walkforward-2023-2026-exploratoria | DOCUMENTARY_RECORD | h1-ou25-walkforward-2023-2026-exploratoria | exploratoria | 2026-07-26T01:09:25Z | n=567, ROI 11,48%; ampliação após resultado conhecido | Manter seleção no denominador; não chamar confirmação | data/trials.json#name=h1-ou25-walkforward-2023-2026-exploratoria | Não reexecutado; variantes não são hipóteses independentes |

| ID | Hipótese | Estado | ID original | Estado original | Data registrada | Avaliação documental | Próxima evidência necessária | Fonte | Limite |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| BR-AUDIT-TRIAL-09 | Entrada documental: h7-clv-prospectivo-pinnacle-2026 | DOCUMENTARY_RECORD | h7-clv-prospectivo-pinnacle-2026 | inconclusiva | 2026-07-26T02:58:15Z | Protocolo de CLV, mínimo específico 50; CLV não prova lucro líquido | Conferir recibo de fechamento e regra própria de acesso | data/trials.json#name=h7-clv-prospectivo-pinnacle-2026 | Não reexecutado; variantes não são hipóteses independentes |

| ID | Hipótese | Estado | ID original | Estado original | Data registrada | Avaliação documental | Próxima evidência necessária | Fonte | Limite |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| BR-AUDIT-TRIAL-10 | Entrada documental: h8-ou25-train-2023-2025-test-2026-observed | DOCUMENTARY_RECORD | h8-ou25-train-2023-2025-test-2026-observed | exploratoria | 2026-08-09T04:15:02Z | Recorte observado n=76, ROI 9,93%, IC [-14,70%; 35,39%] | Estabelecer nova separação temporal para futura replicação | data/trials.json#name=h8-ou25-train-2023-2025-test-2026-observed | Não reexecutado; variantes não são hipóteses independentes |

| ID | Hipótese | Estado | ID original | Estado original | Data registrada | Avaliação documental | Próxima evidência necessária | Fonte | Limite |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| BR-AUDIT-TRIAL-11 | Entrada documental: h9-ou25-prospective-replication | DOCUMENTARY_RECORD | h9-ou25-prospective-replication | inconclusiva | 2026-08-09T05:08:43Z | Protocolo prospectivo; resultados não examinados por proteção | Cumprir contrato H9 e liberação específica | data/trials.json#name=h9-ou25-prospective-replication | Não reexecutado; variantes não são hipóteses independentes |

| ID | Hipótese | Estado | ID original | Estado original | Data registrada | Avaliação documental | Próxima evidência necessária | Fonte | Limite |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| BR-AUDIT-TRIAL-12 | Entrada documental: h11-refit-cadence-rodada-vs-100jogos | DOCUMENTARY_RECORD | h11-refit-cadence-rodada-vs-100jogos | refutada | 2026-08-21T05:17:36Z | Retrospectivo n=1318, ganho RPS 0,001764, IC [-0,001650; 0,004750] | Preservar ausência de superioridade demonstrada, sem inferir efeito zero | data/trials.json#name=h11-refit-cadence-rodada-vs-100jogos | Não reexecutado; variantes não são hipóteses independentes |

| ID | Hipótese | Estado | ID original | Estado original | Data registrada | Avaliação documental | Próxima evidência necessária | Fonte | Limite |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| BR-AUDIT-TRIAL-13 | Entrada documental: h11-v2-refit10-vs-100-retrospective-reanalysis | DOCUMENTARY_RECORD | h11-v2-refit10-vs-100-retrospective-reanalysis | inconclusiva | 2026-08-26T23:40:00Z | Segunda análise do mesmo painel; não é réplica independente | Preservar duas olhadas e separar H15 futuro | data/trials.json#name=h11-v2-refit10-vs-100-retrospective-reanalysis | Não reexecutado; variantes não são hipóteses independentes |

| ID | Hipótese | Estado | ID original | Estado original | Data registrada | Avaliação documental | Próxima evidência necessária | Fonte | Limite |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| BR-AUDIT-TRIAL-14 | Entrada documental: h15-refit10-vs-100-serving-v2-prospectivo | DOCUMENTARY_RECORD | h15-refit10-vs-100-serving-v2-prospectivo | pre-registrada | 2026-08-26T23:41:00Z | Desenho prospectivo, resultados protegidos; incompatibilidade de guardrail | Resolver contrato versus implementação antes de acesso à coorte | data/trials.json#name=h15-refit10-vs-100-serving-v2-prospectivo | Não reexecutado; variantes não são hipóteses independentes |

| ID | Hipótese | Estado | ID original | Estado original | Data registrada | Avaliação documental | Próxima evidência necessária | Fonte | Limite |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| BR-AUDIT-TRIAL-15 | Entrada documental: h12-ensemble-xg-ligado-vs-desligado | DOCUMENTARY_RECORD | h12-ensemble-xg-ligado-vs-desligado | comprovada | 2026-08-22T06:43:15Z | Histórico n=1318: desligado melhor em RPS, ganho 0,004410, IC [0,001436; 0,007741] | Conferir identidade dos painéis para reprodução futura, sem generalização | data/trials.json#name=h12-ensemble-xg-ligado-vs-desligado | Não reexecutado; variantes não são hipóteses independentes |

| ID | Hipótese | Estado | ID original | Estado original | Data registrada | Avaliação documental | Próxima evidência necessária | Fonte | Limite |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| BR-AUDIT-TRIAL-16 | Entrada documental: h13-serving-vs-climatologia-prospectivo | DOCUMENTARY_RECORD | h13-serving-vs-climatologia-prospectivo | substituida | 2026-08-22T13:57:33Z | Protocolo substituído após correções matemáticas | Preservar sucessão para H14, sem mesclar coortes | data/trials.json#name=h13-serving-vs-climatologia-prospectivo | Não reexecutado; variantes não são hipóteses independentes |

| ID | Hipótese | Estado | ID original | Estado original | Data registrada | Avaliação documental | Próxima evidência necessária | Fonte | Limite |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| BR-AUDIT-TRIAL-17 | Entrada documental: market-03-edge-ordering-sofascore-diagnostic | DOCUMENTARY_RECORD | market-03-edge-ordering-sofascore-diagnostic | refutada | 2026-08-24T06:30:00Z | Diagnóstico histórico; 60 células; comparações selecionadas | Preservar conjunto de tentativas e encerramento | data/trials.json#name=market-03-edge-ordering-sofascore-diagnostic | Não reexecutado; variantes não são hipóteses independentes |

| ID | Hipótese | Estado | ID original | Estado original | Data registrada | Avaliação documental | Próxima evidência necessária | Fonte | Limite |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| BR-AUDIT-TRIAL-18 | Entrada documental: market-04-ou25-btts-resolution-and-ordering | DOCUMENTARY_RECORD | market-04-ou25-btts-resolution-and-ordering | refutada | 2026-08-24T12:00:00Z | Dev: OU passa resolução, BTTS falha; validação 2024 não aberta | Não transformar gate de resolução em refutação universal | data/trials.json#name=market-04-ou25-btts-resolution-and-ordering | Não reexecutado; variantes não são hipóteses independentes |

| ID | Hipótese | Estado | ID original | Estado original | Data registrada | Avaliação documental | Próxima evidência necessária | Fonte | Limite |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| BR-AUDIT-TRIAL-19 | Entrada documental: pit-absences-new-information | DOCUMENTARY_RECORD | pit-absences-new-information | pre-registrada | 2026-08-24T12:01:00Z | Hipótese de informação incremental; execução não comprovada | Demonstrar disponibilidade temporal das ausências | data/trials.json#name=pit-absences-new-information | Não reexecutado; variantes não são hipóteses independentes |

| ID | Hipótese | Estado | ID original | Estado original | Data registrada | Avaliação documental | Próxima evidência necessária | Fonte | Limite |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| BR-AUDIT-TRIAL-20 | Entrada documental: pit-lineup-strength-new-information | DOCUMENTARY_RECORD | pit-lineup-strength-new-information | pre-registrada | 2026-08-24T12:02:00Z | Hipótese de escalações; execução não comprovada | Demonstrar publicação/recebimento antes do cutoff | data/trials.json#name=pit-lineup-strength-new-information | Não reexecutado; variantes não são hipóteses independentes |

| ID | Hipótese | Estado | ID original | Estado original | Data registrada | Avaliação documental | Próxima evidência necessária | Fonte | Limite |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| BR-AUDIT-TRIAL-21 | Entrada documental: pit-isolated-xg-new-lineage | DOCUMENTARY_RECORD | pit-isolated-xg-new-lineage | pre-registrada | 2026-08-24T12:03:00Z | Nova linhagem proposta; não resolve automaticamente integrated_xg_v2 | Resolver identidade e disponibilidade das revisões de xG | data/trials.json#name=pit-isolated-xg-new-lineage | Não reexecutado; variantes não são hipóteses independentes |

| ID | Hipótese | Estado | ID original | Estado original | Data registrada | Avaliação documental | Próxima evidência necessária | Fonte | Limite |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| BR-AUDIT-TRIAL-22 | Entrada documental: pit-hierarchical-team-home-advantage | DOCUMENTARY_RECORD | pit-hierarchical-team-home-advantage | pre-registrada | 2026-08-24T12:04:00Z | Hipótese de efeito hierárquico; execução não comprovada | Localizar protocolo/versionamento anterior à avaliação | data/trials.json#name=pit-hierarchical-team-home-advantage | Não reexecutado; variantes não são hipóteses independentes |

| ID | Hipótese | Estado | ID original | Estado original | Data registrada | Avaliação documental | Próxima evidência necessária | Fonte | Limite |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| BR-AUDIT-TRIAL-23 | Entrada documental: live-backtest-viability-gate | DOCUMENTARY_RECORD | live-backtest-viability-gate | inconclusiva | 2026-08-24T12:05:00Z | Gate de viabilidade; não é resultado de superioridade | Localizar dados elegíveis para o contrato concreto | data/trials.json#name=live-backtest-viability-gate | Não reexecutado; variantes não são hipóteses independentes |

| ID | Hipótese | Estado | ID original | Estado original | Data registrada | Avaliação documental | Próxima evidência necessária | Fonte | Limite |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| BR-AUDIT-TRIAL-24 | Entrada documental: prospective-paper-validation-governance | DOCUMENTARY_RECORD | prospective-paper-validation-governance | informativa | 2026-08-24T12:06:00Z | Entrada de governança; métricas preditivas não aplicáveis | Conferir mecanismo de bloqueio e recibos autorizados | data/trials.json#name=prospective-paper-validation-governance | Não reexecutado; variantes não são hipóteses independentes |

| ID | Hipótese | Estado | ID original | Estado original | Data registrada | Avaliação documental | Próxima evidência necessária | Fonte | Limite |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| BR-AUDIT-TRIAL-25 | Entrada documental: market-05-pinnacle-soft-structural-edge | DOCUMENTARY_RECORD | market-05-pinnacle-soft-structural-edge | pre-registrada | 2026-08-24T18:00:00Z | Protocolo de referência Pinnacle versus softbooks; resultados protegidos | Resolver versão do contrato e fricções antes de qualquer claim | data/trials.json#name=market-05-pinnacle-soft-structural-edge | Não reexecutado; variantes não são hipóteses independentes |

| ID | Hipótese | Estado | ID original | Estado original | Data registrada | Avaliação documental | Próxima evidência necessária | Fonte | Limite |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| BR-AUDIT-TRIAL-26 | Entrada documental: market-06-ou25-dev-only-ordering-triage | DOCUMENTARY_RECORD | market-06-ou25-dev-only-ordering-triage | refutada | 2026-08-24T14:00:00Z | Dev n=808 com odds; extremo n=3, sem monotonicidade; sem validação 2024 | Preservar NO_GO dentro do desenho | data/trials.json#name=market-06-ou25-dev-only-ordering-triage | Não reexecutado; variantes não são hipóteses independentes |

| ID | Hipótese | Estado | ID original | Estado original | Data registrada | Avaliação documental | Próxima evidência necessária | Fonte | Limite |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| BR-AUDIT-TRIAL-27 | Entrada documental: observation-2026-inter-bahia-slow-reactivity | DOCUMENTARY_RECORD | observation-2026-inter-bahia-slow-reactivity | informativa | 2026-08-24T15:00:00Z | Observação, não experimento confirmatório | Localizar registro temporal e não generalizar o caso | data/trials.json#name=observation-2026-inter-bahia-slow-reactivity | Não reexecutado; variantes não são hipóteses independentes |

| ID | Hipótese | Estado | ID original | Estado original | Data registrada | Avaliação documental | Próxima evidência necessária | Fonte | Limite |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| BR-AUDIT-TRIAL-28 | Entrada documental: market05-a1-shadow | DOCUMENTARY_RECORD | market05-a1-shadow | pre-registrada | 2026-08-24T21:00:00Z | Calibração operacional sem labels; resultados protegidos | Gates A1, freeze e liberação específica; não consultar P&L | data/trials.json#name=market05-a1-shadow | Não reexecutado; variantes não são hipóteses independentes |

| ID | Hipótese | Estado | ID original | Estado original | Data registrada | Avaliação documental | Próxima evidência necessária | Fonte | Limite |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| BR-AUDIT-TRIAL-29 | Entrada documental: h14-serving-v2-vs-climatologia-prequential-prospectivo | DOCUMENTARY_RECORD | h14-serving-v2-vs-climatologia-prequential-prospectivo | pre-registrada | 2026-08-26T22:35:33Z | Desenho prospectivo; resultados protegidos; guardrail OU2.5 ausente do avaliador | Resolver incompatibilidade sem reconstruir previsões ou mudar contrato | data/trials.json#name=h14-serving-v2-vs-climatologia-prequential-prospectivo | Não reexecutado; variantes não são hipóteses independentes |

| ID | Hipótese | Estado | ID original | L | Q | Evidência | Limites originais | Seleção | Decisão | Retificação da auditoria |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| BR-AUDIT-CLAIM-BR-MARKET-001 | Model has incremental information vs market at H-24h | BLOCKED_PENDING_PIT_FEATURES | CLAIM-BR-MARKET-001 | HISTORICAL_PIT | COVERAGE_AUDITED | no model comparison executed | 245/245 odds coverage in 2026; no multi-season odds; feature availability not proven; 3 snapshots older than 24h | EXP-001 → H24, fixed before results | no claim | 245/245 é cobertura declarada antiga; não prova cotação válida no cutoff |

| ID | Hipótese | Estado | ID original | L | Q | Evidência | Limites originais | Seleção | Decisão | Retificação da auditoria |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| BR-AUDIT-CLAIM-BR-MARKET-002 | Model has incremental information vs market at H-6h | BLOCKED_PENDING_PIT_FEATURES | CLAIM-BR-MARKET-002 | HISTORICAL_PIT | COVERAGE_AUDITED | no model comparison executed | 245/245 odds coverage in 2026; no multi-season odds; feature availability not proven; 4 snapshots older than 24h | EXP-001 → H6, fixed before results | no claim | 245/245 é cobertura declarada antiga; não prova cotação válida no cutoff |

| ID | Hipótese | Estado | ID original | L | Q | Evidência | Limites originais | Seleção | Decisão | Retificação da auditoria |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| BR-AUDIT-CLAIM-BR-MARKET-003 | Model has incremental information vs market at H-1h | BLOCKED_PENDING_PIT_FEATURES | CLAIM-BR-MARKET-003 | HISTORICAL_PIT | COVERAGE_AUDITED | no model comparison executed | 245/245 odds coverage in 2026; no multi-season odds; feature availability not proven; 3 snapshots older than 24h | EXP-001 → H1, fixed before results | no claim | 245/245 é cobertura declarada antiga; não prova cotação válida no cutoff |

| ID | Hipótese | Estado | ID original | Limite |
| --- | --- | --- | --- | --- |
| BR-AUDIT-H11-IDENTIDADE | Protocolo histórico de ensemble distinto da cadência de refit | LINEAGE_UNRESOLVED | h11-ensemble-xg-1x2-prospective-2026 | Não unir com H11/H11-v2 de cadência sem fonte de ligação/supersessão |

| ID | Hipótese | Estado | Jogo | Braço | Previsão original em | Kickoff | 1X2 original | OU2.5 original | OU2.5 reconstruído | Proveniência | Limites | Original SHA256 |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| BR-AUDIT-H14-15235455-serving_v2 | Registro histórico da previsão por braço | ORIGINAL_1X2_ONLY | Red Bull Bragantino / Bahia | serving_v2 | 2026-09-04T19:00:09+00:00 | 2026-09-05T19:00:00+00:00 | {"p_away": 0.268425, "p_draw": 0.270369, "p_home": 0.461207} | AUSENTE | NÃO RECUPERADO | [] | Sem resultados usados; código original não plenamente comprovado; elegibilidade prospectiva NÃO restaurada | 00030c961a3b42760a9f8d41fde096c213b75b5ec65e9b74f3f0809898789d99 |

| ID | Hipótese | Estado | Jogo | Braço | Previsão original em | Kickoff | 1X2 original | OU2.5 original | OU2.5 reconstruído | Proveniência | Limites | Original SHA256 |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| BR-AUDIT-H14-15235455-climatology | Registro histórico da previsão por braço | ORIGINAL_1X2_ONLY | Red Bull Bragantino / Bahia | climatology | 2026-09-04T19:00:09+00:00 | 2026-09-05T19:00:00+00:00 | {"p_away": 0.257049, "p_draw": 0.275846, "p_home": 0.467105} | AUSENTE | NÃO RECUPERADO | [] | Sem resultados usados; código original não plenamente comprovado; elegibilidade prospectiva NÃO restaurada | 00030c961a3b42760a9f8d41fde096c213b75b5ec65e9b74f3f0809898789d99 |

| ID | Hipótese | Estado | Jogo | Braço | Previsão original em | Kickoff | 1X2 original | OU2.5 original | OU2.5 reconstruído | Proveniência | Limites | Original SHA256 |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| BR-AUDIT-H14-15235459-serving_v2 | Registro histórico da previsão por braço | ORIGINAL_1X2_ONLY | São Paulo / Atlético Mineiro | serving_v2 | 2026-09-04T21:45:27+00:00 | 2026-09-05T21:30:00+00:00 | {"p_away": 0.335435, "p_draw": 0.27896, "p_home": 0.385605} | AUSENTE | NÃO RECUPERADO | [] | Sem resultados usados; código original não plenamente comprovado; elegibilidade prospectiva NÃO restaurada | 00030c961a3b42760a9f8d41fde096c213b75b5ec65e9b74f3f0809898789d99 |

| ID | Hipótese | Estado | Jogo | Braço | Previsão original em | Kickoff | 1X2 original | OU2.5 original | OU2.5 reconstruído | Proveniência | Limites | Original SHA256 |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| BR-AUDIT-H14-15235459-climatology | Registro histórico da previsão por braço | ORIGINAL_1X2_ONLY | São Paulo / Atlético Mineiro | climatology | 2026-09-04T21:45:27+00:00 | 2026-09-05T21:30:00+00:00 | {"p_away": 0.257049, "p_draw": 0.275846, "p_home": 0.467105} | AUSENTE | NÃO RECUPERADO | [] | Sem resultados usados; código original não plenamente comprovado; elegibilidade prospectiva NÃO restaurada | 00030c961a3b42760a9f8d41fde096c213b75b5ec65e9b74f3f0809898789d99 |

| ID | Hipótese | Estado | Jogo | Braço | Previsão original em | Kickoff | 1X2 original | OU2.5 original | OU2.5 reconstruído | Proveniência | Limites | Original SHA256 |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| BR-AUDIT-H14-15235465-serving_v2 | Registro histórico da previsão por braço | ORIGINAL_1X2_ONLY | Vitória / Grêmio | serving_v2 | 2026-09-07T18:33:32+00:00 | 2026-09-07T23:00:00+00:00 | {"p_away": 0.294396, "p_draw": 0.2707, "p_home": 0.434904} | AUSENTE | NÃO RECUPERADO | [] | Sem resultados usados; código original não plenamente comprovado; elegibilidade prospectiva NÃO restaurada | 00030c961a3b42760a9f8d41fde096c213b75b5ec65e9b74f3f0809898789d99 |

| ID | Hipótese | Estado | Jogo | Braço | Previsão original em | Kickoff | 1X2 original | OU2.5 original | OU2.5 reconstruído | Proveniência | Limites | Original SHA256 |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| BR-AUDIT-H14-15235465-climatology | Registro histórico da previsão por braço | ORIGINAL_1X2_ONLY | Vitória / Grêmio | climatology | 2026-09-07T18:33:32+00:00 | 2026-09-07T23:00:00+00:00 | {"p_away": 0.257646, "p_draw": 0.274328, "p_home": 0.468026} | AUSENTE | NÃO RECUPERADO | [] | Sem resultados usados; código original não plenamente comprovado; elegibilidade prospectiva NÃO restaurada | 00030c961a3b42760a9f8d41fde096c213b75b5ec65e9b74f3f0809898789d99 |

| ID | Hipótese | Estado | Jogo | Braço | Previsão original em | Kickoff | 1X2 original | OU2.5 original | OU2.5 reconstruído | Proveniência | Limites | Original SHA256 |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| BR-AUDIT-H15-15235455-control_refit100 | Registro histórico da previsão por braço | ORIGINAL_1X2_ONLY | Red Bull Bragantino / Bahia | control_refit100 | 2026-09-04T19:01:09+00:00 | 2026-09-05T19:00:00+00:00 | {"p_away": 0.268425, "p_draw": 0.270369, "p_home": 0.461207} | AUSENTE | NÃO RECUPERADO | [] | Sem resultados usados; código original não plenamente comprovado; elegibilidade prospectiva NÃO restaurada | f3337e0567c53ac3af15b2e8ef3113470a5c7e854e3b69f269418fa38230a46f |

| ID | Hipótese | Estado | Jogo | Braço | Previsão original em | Kickoff | 1X2 original | OU2.5 original | OU2.5 reconstruído | Proveniência | Limites | Original SHA256 |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| BR-AUDIT-H15-15235455-treatment_refit10 | Registro histórico da previsão por braço | ORIGINAL_1X2_ONLY | Red Bull Bragantino / Bahia | treatment_refit10 | 2026-09-04T19:01:09+00:00 | 2026-09-05T19:00:00+00:00 | {"p_away": 0.268425, "p_draw": 0.270369, "p_home": 0.461207} | AUSENTE | NÃO RECUPERADO | [] | Sem resultados usados; código original não plenamente comprovado; elegibilidade prospectiva NÃO restaurada | f3337e0567c53ac3af15b2e8ef3113470a5c7e854e3b69f269418fa38230a46f |

| ID | Hipótese | Estado | Jogo | Braço | Previsão original em | Kickoff | 1X2 original | OU2.5 original | OU2.5 reconstruído | Proveniência | Limites | Original SHA256 |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| BR-AUDIT-H15-15235459-control_refit100 | Registro histórico da previsão por braço | ORIGINAL_1X2_ONLY | São Paulo / Atlético Mineiro | control_refit100 | 2026-09-04T21:46:15+00:00 | 2026-09-05T21:30:00+00:00 | {"p_away": 0.335435, "p_draw": 0.27896, "p_home": 0.385605} | AUSENTE | NÃO RECUPERADO | [] | Sem resultados usados; código original não plenamente comprovado; elegibilidade prospectiva NÃO restaurada | f3337e0567c53ac3af15b2e8ef3113470a5c7e854e3b69f269418fa38230a46f |

| ID | Hipótese | Estado | Jogo | Braço | Previsão original em | Kickoff | 1X2 original | OU2.5 original | OU2.5 reconstruído | Proveniência | Limites | Original SHA256 |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| BR-AUDIT-H15-15235459-treatment_refit10 | Registro histórico da previsão por braço | ORIGINAL_1X2_ONLY | São Paulo / Atlético Mineiro | treatment_refit10 | 2026-09-04T21:46:15+00:00 | 2026-09-05T21:30:00+00:00 | {"p_away": 0.335435, "p_draw": 0.27896, "p_home": 0.385605} | AUSENTE | NÃO RECUPERADO | [] | Sem resultados usados; código original não plenamente comprovado; elegibilidade prospectiva NÃO restaurada | f3337e0567c53ac3af15b2e8ef3113470a5c7e854e3b69f269418fa38230a46f |

| ID | Hipótese | Estado | Jogo | Braço | Previsão original em | Kickoff | 1X2 original | OU2.5 original | OU2.5 reconstruído | Proveniência | Limites | Original SHA256 |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| BR-AUDIT-H15-15235465-control_refit100 | Registro histórico da previsão por braço | RETROSPECTIVE_RECONSTRUCTION | Vitória / Grêmio | control_refit100 | 2026-09-07T18:33:32+00:00 | 2026-09-07T23:00:00+00:00 | {"p_away": 0.263428, "p_draw": 0.269275, "p_home": 0.467297} | AUSENTE | 0.4442837268151394 | ["901a02ae7456e256899cc021f65ff777e7c86c9328d6f709d7712b5fe1c29f1c:8661fb3284ecb1904280c8a90a6d5ae5554ce12426967b2a972e24b36a531a42", "901a02ae7456e256899cc021f65ff777e7c86c9328d6f709d7712b5fe1c29f1c:a0ddbb4353839fc31231ac159fdc48a9e87378f43effb65b1f02dfb9642e6009"] | Sem resultados usados; código original não plenamente comprovado; elegibilidade prospectiva NÃO restaurada | f3337e0567c53ac3af15b2e8ef3113470a5c7e854e3b69f269418fa38230a46f |

| ID | Hipótese | Estado | Jogo | Braço | Previsão original em | Kickoff | 1X2 original | OU2.5 original | OU2.5 reconstruído | Proveniência | Limites | Original SHA256 |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| BR-AUDIT-H15-15235465-treatment_refit10 | Registro histórico da previsão por braço | RETROSPECTIVE_RECONSTRUCTION | Vitória / Grêmio | treatment_refit10 | 2026-09-07T18:33:32+00:00 | 2026-09-07T23:00:00+00:00 | {"p_away": 0.294396, "p_draw": 0.2707, "p_home": 0.434904} | AUSENTE | 0.4434805808726347 | ["dfe34043d80cdcb1bd7b925aa2e7aa5738f2755138aee69d3f543420210555bf:8661fb3284ecb1904280c8a90a6d5ae5554ce12426967b2a972e24b36a531a42", "dfe34043d80cdcb1bd7b925aa2e7aa5738f2755138aee69d3f543420210555bf:a0ddbb4353839fc31231ac159fdc48a9e87378f43effb65b1f02dfb9642e6009"] | Sem resultados usados; código original não plenamente comprovado; elegibilidade prospectiva NÃO restaurada | f3337e0567c53ac3af15b2e8ef3113470a5c7e854e3b69f269418fa38230a46f |

| ID | Hipótese | Estado | ID do protocolo | Instalação | Coleta nova | Inscrição canônica | Coortes antigas | Capital | Fonte |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| BR-AUDIT-PROTOCOLO-V2 | Especificação sucessora separada das coortes antigas | SPECIFIED_NOT_ACTIVATED | br-prospective-repair-v2-20260915 | Biblioteca instalada; 155 testes passaram | NÃO ATIVADA | NÃO EFETUADA | Não elegíveis para o protocolo sucessor; contratos antigos preservados | DESABILITADO | PROTOCOLO_SUCESSOR_V2.json |

| ID | Hipótese | Estado | Arquivo | Git remoto | SHA256 | Estado literal no documento | Limite | Proveniência | Ressalva adicional |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| BR-AUDIT-EXP001-COVERAGE-IDENTITY-ASSESSMENT | Relatório complementar histórico obtido do repositório remoto | RECOVERED_COMPLEMENTARY_DOCUMENT | reports/exp001_coverage_identity_assessment_2026-09-02.json | 460a397adc2f0dbe11ed6bda83aa9a8009d04549 | 215e92932b6763ede1aa563ecc06bbc8641b59e077ff4277f96e37a90441bfc4 | PARTIALLY_READY | Documento de 2026-09-02; não substitui os dois originais ausentes nem comprova estado atual | https://github.com/leonardosovienski/brasileirao-predictor/blob/460a397adc2f0dbe11ed6bda83aa9a8009d04549/reports/exp001_coverage_identity_assessment_2026-09-02.json | Cobertura antiga não prova disponibilidade das features nem cotação válida no corte |

| ID | Hipótese | Estado | Arquivo | Git remoto | SHA256 | Estado literal no documento | Limite | Proveniência | Ressalva adicional |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| BR-AUDIT-EXP001-FEATURE-PIT-AUDIT | Relatório complementar histórico obtido do repositório remoto | RECOVERED_COMPLEMENTARY_DOCUMENT | reports/exp001_feature_pit_audit_2026-09-02.json | 460a397adc2f0dbe11ed6bda83aa9a8009d04549 | f83662255c4236e938af227728332019b8f7123f5a8369d7728eb13028ee6307 | FAIL_CLOSED | Documento de 2026-09-02; não substitui os dois originais ausentes nem comprova estado atual | https://github.com/leonardosovienski/brasileirao-predictor/blob/460a397adc2f0dbe11ed6bda83aa9a8009d04549/reports/exp001_feature_pit_audit_2026-09-02.json | Cobertura antiga não prova disponibilidade das features nem cotação válida no corte |

| ID | Hipótese | Estado | Arquivo | Git remoto | SHA256 | Estado literal no documento | Limite | Proveniência | Ressalva adicional |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| BR-AUDIT-EXP001-READINESS-DECISION | Relatório complementar histórico obtido do repositório remoto | RECOVERED_COMPLEMENTARY_DOCUMENT | reports/exp001_readiness_decision_2026-09-02.json | 460a397adc2f0dbe11ed6bda83aa9a8009d04549 | b9eb9c805e6678e36790dc46c3670f803e5b1ee61dd3ebd4e6c6c02ef5457a72 | PARTIALLY_READY | Documento de 2026-09-02; não substitui os dois originais ausentes nem comprova estado atual | https://github.com/leonardosovienski/brasileirao-predictor/blob/460a397adc2f0dbe11ed6bda83aa9a8009d04549/reports/exp001_readiness_decision_2026-09-02.json | Cobertura antiga não prova disponibilidade das features nem cotação válida no corte |

| ID | Hipótese | Estado | O que foi buscado | Limite | Preenchimento automático |
| --- | --- | --- | --- | --- | --- |
| BR-AUDIT-FALTA-H14-OU25 | Seis OU2.5 históricos H14 | NOT_RECOVERED_IN_REVIEWED_SOURCES | Arquivos preservados, 16 ZIPs, 12 revisões de configuração e Git remoto atualizado | Grade/estado e definição histórica da baseline insuficientes | NÃO; não inventar números, timestamps ou equivalências |

| ID | Hipótese | Estado | O que foi buscado | Limite | Preenchimento automático |
| --- | --- | --- | --- | --- | --- |
| BR-AUDIT-FALTA-H15-OU25 | Quatro OU2.5 históricos H15 | NOT_RECOVERED_IN_REVIEWED_SOURCES | Arquivos preservados, 16 ZIPs, 12 revisões de configuração e Git remoto atualizado | Estados e configurações não satisfazem toda a proveniência exigida | NÃO; não inventar números, timestamps ou equivalências |

| ID | Hipótese | Estado | O que foi buscado | Limite | Preenchimento automático |
| --- | --- | --- | --- | --- | --- |
| BR-AUDIT-FALTA-EXP001-PILOT | reports/exp001_data_pilot_2026-09-02.json | NOT_RECOVERED_IN_REVIEWED_SOURCES | Arquivos preservados, 16 ZIPs, 12 revisões de configuração e Git remoto atualizado | Ausente nos arquivos e histórico remoto consultados | NÃO; não inventar números, timestamps ou equivalências |

| ID | Hipótese | Estado | O que foi buscado | Limite | Preenchimento automático |
| --- | --- | --- | --- | --- | --- |
| BR-AUDIT-FALTA-EXP001-COVERAGE | reports/exp001_coverage_audit_2026-09-02.json | NOT_RECOVERED_IN_REVIEWED_SOURCES | Arquivos preservados, 16 ZIPs, 12 revisões de configuração e Git remoto atualizado | Ausente nos arquivos e histórico remoto consultados | NÃO; não inventar números, timestamps ou equivalências |

| ID | Hipótese | Estado | O que foi buscado | Limite | Preenchimento automático |
| --- | --- | --- | --- | --- | --- |
| BR-AUDIT-FALTA-INTEGRATED-XG-V2 | Identidade integrated_xg_v2 | NOT_RECOVERED_IN_REVIEWED_SOURCES | Arquivos preservados, 16 ZIPs, 12 revisões de configuração e Git remoto atualizado | Identidade de artefato não resolvida; não inferir equivalência | NÃO; não inventar números, timestamps ou equivalências |

| ID | Hipótese | Estado | O que foi buscado | Limite | Preenchimento automático |
| --- | --- | --- | --- | --- | --- |
| BR-AUDIT-FALTA-FEATURE-PIT | Timestamps históricos de publicação de resultados/features | NOT_RECOVERED_IN_REVIEWED_SOURCES | Arquivos preservados, 16 ZIPs, 12 revisões de configuração e Git remoto atualizado | Não podem ser substituídos pelo kickoff ou pela data de obtenção atual | NÃO; não inventar números, timestamps ou equivalências |

