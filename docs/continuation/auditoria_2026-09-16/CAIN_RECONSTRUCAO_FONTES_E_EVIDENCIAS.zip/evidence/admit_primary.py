"""Append the verified audit stream to the existing Brasileirão collection."""
import base64
from collections import Counter
import json
import os
import sqlite3
import sys
from datetime import datetime, timezone
from pathlib import Path

sys.dont_write_bytecode = True
from research_snapshot import canonical, digest
from cain.research import ResearchService
from cain.research.analysis import review
from cain.research.inspection import inspect
from build_package import BASE, cell
from verify_package import grant, NoGeneration


def hashes(connection):
    result = {}
    tables = [r[0] for r in connection.execute("SELECT name FROM sqlite_master WHERE type='table'")]
    for table in tables:
        escaped = table.replace('"', '""')
        rows = connection.execute('SELECT * FROM "' + escaped + '"').fetchall()
        result[table] = Counter(digest(canonical([
            {'blob': base64.b64encode(v).decode()} if isinstance(v, bytes) else v for v in row])) for row in rows)
    return result


def main():
    annex = '--annex' in sys.argv
    suffix = '-annex' if annex else ''
    qa = json.loads((BASE / ('qa-annex2' if annex else 'qa-01') / 'verification.json').read_text(encoding='utf-8'))
    manifest = json.loads((BASE / ('manifest' + suffix + '.json')).read_text(encoding='utf-8'))
    assert qa['literal_queries_passed'] == manifest['record_count'] and not qa['failures']
    for path, expected in manifest['original_hashes'].items():
        assert digest(Path(path).read_bytes()) == expected
    policy_path = Path('C:/CAIN/config/research-policy.json')
    database = Path('C:/CAIN/dados/research.db')
    original_policy = policy_path.read_bytes()
    policy = json.loads(original_policy)
    binding = [b for b in policy['imports'] if b['user'] == 'leo' and b['project'] == ''
               and b['collection'] == 'brasileirao']
    assert len(binding) == 1
    inbox = Path(binding[0]['root'])
    added = grant('leo', manifest['source'])
    assert added not in policy['grants'], 'Already admitted; inspect receipt instead of rerunning'
    backup = BASE / ('primary-backup' + suffix)
    backup.mkdir(exist_ok=False)
    (backup / 'research-policy.before.json').write_bytes(original_policy)
    with sqlite3.connect(database.as_uri() + '?mode=ro', uri=True) as source:
        with sqlite3.connect(backup / 'research.before.db') as destination:
            source.backup(destination)
            assert destination.execute('PRAGMA integrity_check').fetchone()[0] == 'ok'
            before = hashes(destination)
    # Add one narrowly scoped permission; preserve all existing bindings/grants.
    policy['grants'].append(added)
    updated = canonical(policy)
    staged_policy = BASE / 'primary-policy.validated.json'
    staged_policy.write_bytes(updated)
    ResearchService(BASE / 'policy-validation.db', staged_policy)
    for pubid in manifest['packages']:
        payload = (BASE / 'publications' / (pubid + '.json')).read_bytes()
        target = inbox / (pubid + '.json')
        if target.exists():
            assert target.read_bytes() == payload
        else:
            with target.open('xb') as stream:
                stream.write(payload)
    assert policy_path.read_bytes() == original_policy, 'Concurrent policy change'
    temporary = policy_path.with_name('research-policy.br-audit.pending.json')
    with temporary.open('xb') as stream:
        stream.write(updated)
    os.replace(temporary, policy_path)
    service = ResearchService(database, policy_path)
    scope = service.scope('leo', collection='brasileirao')
    receipts, checks = [], []
    try:
        for pubid in manifest['packages']:
            receipt = service.ingest(pubid + '.json', scope)
            receipts.append(receipt)
            assert receipt['status'] == 'admitted', receipt
        for row in manifest['records']:
            result = review(service, scope, 'O que a fonte registra sobre ' + row['id'] + '?',
                            NoGeneration(), role='synthesis', source_id=row['id'])
            text = result.get('explanation', {}).get('proposed_synthesis', '')
            assert result['status'] == 'literal_claim_table', (row['id'], result['status'])
            assert result['model_calls'] == 0
            assert all(cell(value) in text for value in row['fields'].values()), row['id']
            checks.append({'id': row['id'], 'status': result['status'], 'fields_verified': len(row['fields'])})
        with service.connection() as connection:
            assert connection.execute('PRAGMA integrity_check').fetchone()[0] == 'ok'
            after = hashes(connection)
            assert all(not (records - after.get(table, Counter())) for table, records in before.items())
        assert policy_path.read_bytes() == updated
        for path, expected in manifest['original_hashes'].items():
            assert digest(Path(path).read_bytes()) == expected
        result = {'at': datetime.now(timezone.utc).isoformat(), 'status': 'ADMITTED_AND_VERIFIED',
                  'database': str(database), 'user': 'leo', 'collection': 'brasileirao',
                  'receipts': receipts, 'new_records': len(checks), 'checks': checks,
                  'all_preexisting_database_rows_preserved': True, 'database_integrity': 'ok',
                  'old_policy_sha256': digest(original_policy), 'new_policy_sha256': digest(updated),
                  'only_policy_change': 'one exact audit-stream grant',
                  'model_calls': 0, 'primary_total_records': len(inspect(service, scope)['records']),
                  'scientific_evaluation_executed': False, 'original_forecasts_preserved': True}
    except BaseException as exc:
        (BASE / ('primary-incomplete' + suffix + '.json')).write_text(json.dumps({'receipts': receipts,
            'verified_so_far': checks, 'error': str(exc), 'note': 'Never restore database over concurrent writes'}), encoding='utf-8')
        raise
    (BASE / ('primary-admission' + suffix + '.json')).write_text(json.dumps(result, ensure_ascii=False, indent=2), encoding='utf-8')
    print(json.dumps({k: v for k, v in result.items() if k not in ('checks', 'receipts')}, ensure_ascii=False))


if __name__ == '__main__':
    main()
