"""Prepare explicitly sourced audit knowledge; no invented forecasts or outcomes."""
import json
import subprocess
import sys
from datetime import datetime, timezone
from pathlib import Path

sys.dont_write_bytecode = True
from research_snapshot import canonical, digest, seal, validate

BASE = Path(__file__).parent
OUT = Path('C:/Users/leona/Documents/Codex/2026-09-15/lea/outputs')
BR = Path('C:/BRASILEIRAO/brasileirao-predictor')
RECOVERY = Path('C:/BRASILEIRAO/work/audit-fixes-20260915')
SOURCE = 'local-audit/brasileirao-reconstruction-20260915.md'
REPOSITORY = 'https://github.com/leonardosovienski/brasileirao-predictor'
PUBLISHER, STREAM, POLICY = 'local-audit-curation', 'reconstruction-audit', 'brasileirao-audit/1'


def cell(value):
    if not isinstance(value, str):
        value = json.dumps(value, ensure_ascii=False, sort_keys=True)
    if '|' in value or '\n' in value or '\r' in value:
        raise ValueError('A literal table cell cannot hide delimiters/newlines')
    return value


def build():
    BASE.mkdir(exist_ok=True)
    rows, originals = [], {}

    def read(path):
        raw = path.read_bytes()
        originals[str(path)] = digest(raw)
        return raw

    def add(identity, description, state, fields):
        columns = {'ID': identity, 'Hipótese': description, 'Estado': state, **fields}
        table = ('| ' + ' | '.join(columns) + ' |\n| ' + ' | '.join('---' for _ in columns)
                 + ' |\n| ' + ' | '.join(cell(v) for v in columns.values()) + ' |\n')
        rows.append({'id': identity, 'state': state, 'fields': columns, 'text': table})

    add('BR-AUDIT-RESUMO', 'Inventário documental e recuperação histórica', 'PARTIAL_RECOVERY', {
        'O que tem': '29 entradas de trials; 3 claims; 12 previsões por braço originais; 2 OU2.5 retrospectivos H15',
        'O que falta': 'OU2.5 não recuperável em 10 braços; 2 relatórios EXP-001 originais ausentes; OU2.5 original ausente em todos os 12 braços',
        'Distinção': '2 de 6 braços H15 reconstruídos; 0 de 6 braços H14; nenhum OU2.5 foi registrado originalmente',
        'Limites': 'As 2 reconstruções não são previsões originais e não restauram elegibilidade prospectiva',
        'Avaliação científica': 'Nenhuma nesta auditoria; testes de software não demonstram ganho preditivo',
    })
    ledger = json.loads(read(OUT / 'LEDGER_DERIVADO.json'))
    assert len(ledger['entries']) == 29
    for index, entry in enumerate(ledger['entries'], 1):
        native = entry['native_metadata']
        add(f'BR-AUDIT-TRIAL-{index:02}', 'Entrada documental: ' + entry['id'], 'DOCUMENTARY_RECORD', {
            'ID original': entry['id'], 'Estado original': native['status'],
            'Data registrada': native.get('registered_at', 'NÃO INFORMADA'),
            'Avaliação documental': entry['documentary_assessment'],
            'Próxima evidência necessária': entry['next_minimum_check'],
            'Fonte': entry['source'], 'Limite': 'Não reexecutado; variantes não são hipóteses independentes',
        })
    registry = read(BR / 'docs/EVIDENCE_REGISTRY.md').decode('utf-8')
    for line in registry.splitlines():
        if not line.startswith('| CLAIM-BR-MARKET-'):
            continue
        parts = [s.strip() for s in line.strip('|').split('|')]
        identity, hypothesis, state, level, quality, evidence, limitations, selection, decision = parts
        add('BR-AUDIT-' + identity, hypothesis, state, {
            'ID original': identity, 'L': level, 'Q': quality, 'Evidência': evidence,
            'Limites originais': limitations, 'Seleção': selection, 'Decisão': decision,
            'Retificação da auditoria': '245/245 é cobertura declarada antiga; não prova cotação válida no cutoff',
        })
    add('BR-AUDIT-H11-IDENTIDADE', 'Protocolo histórico de ensemble distinto da cadência de refit',
        'LINEAGE_UNRESOLVED', {'ID original': 'h11-ensemble-xg-1x2-prospective-2026',
                               'Limite': 'Não unir com H11/H11-v2 de cadência sem fonte de ligação/supersessão'})
    supplement = json.loads(read(OUT / 'H15_SUPLEMENTO_RETROSPECTIVO_V3.json'))
    reconstructed = {(r['event_id'], arm): value for r in supplement['records'] for arm, value in r['arms'].items()}
    for trial, filename, arms in [('H14', 'h14_serving_vs_climatologia.jsonl', ('serving_v2', 'climatology')),
                                  ('H15', 'h15_refit10_vs_100.jsonl', ('control_refit100', 'treatment_refit10'))]:
        raw = read(RECOVERY / 'forecast-recovery/originals' / filename)
        for line in raw.decode('utf-8').splitlines():
            if not line.strip():
                continue
            row = json.loads(line)
            for arm in arms:
                recovery = reconstructed.get((row['event_id'], arm), {}) if trial == 'H15' else {}
                is_reconstructed = recovery.get('status') == 'RECONSTRUCTED_RETROSPECTIVE'
                fields = {'Jogo': row['home'] + ' / ' + row['away'], 'Braço': arm,
                          'Previsão original em': row['predicted_at'], 'Kickoff': row['kickoff_at'],
                          '1X2 original': {k: row[arm][k] for k in ('p_home', 'p_draw', 'p_away')},
                          'OU2.5 original': 'AUSENTE',
                          'OU2.5 reconstruído': recovery['p_over_2_5'] if is_reconstructed else 'NÃO RECUPERADO',
                          'Proveniência': sorted({v['state_sha256'] + ':' + v['config_sha256']
                                                  for v in recovery.get('matching_provenance', [])}),
                          'Limites': 'Sem resultados usados; código original não plenamente comprovado; elegibilidade prospectiva NÃO restaurada',
                          'Original SHA256': digest(raw)}
                add(f'BR-AUDIT-{trial}-{row["event_id"]}-{arm}', 'Registro histórico da previsão por braço',
                    'RETROSPECTIVE_RECONSTRUCTION' if is_reconstructed else 'ORIGINAL_1X2_ONLY', fields)
    protocol = json.loads(read(OUT / 'PROTOCOLO_SUCESSOR_V2.json'))
    add('BR-AUDIT-PROTOCOLO-V2', 'Especificação sucessora separada das coortes antigas', protocol['status'], {
        'ID do protocolo': protocol['id'], 'Instalação': 'Biblioteca instalada; 155 testes passaram',
        'Coleta nova': 'NÃO ATIVADA', 'Inscrição canônica': 'NÃO EFETUADA',
        'Coortes antigas': 'Não elegíveis para o protocolo sucessor; contratos antigos preservados',
        'Capital': 'DESABILITADO', 'Fonte': 'PROTOCOLO_SUCESSOR_V2.json',
    })
    remote = RECOVERY / 'remote-recovery.git'
    head = subprocess.check_output(['git', '--git-dir=' + str(remote), 'rev-parse', 'HEAD'], text=True).strip()
    recovered = BASE / 'recovered-public'
    recovered.mkdir(exist_ok=True)
    for suffix in ('coverage_identity_assessment', 'feature_pit_audit', 'readiness_decision'):
        name = f'exp001_{suffix}_2026-09-02.json'
        raw = subprocess.check_output(['git', '--git-dir=' + str(remote), 'show', f'{head}:reports/{name}'])
        if (recovered / name).exists():
            assert (recovered / name).read_bytes() == raw
        else:
            with (recovered / name).open('xb') as stream:
                stream.write(raw)
        data = json.loads(raw)
        state = data.get('data_status', data.get('decision', data.get('EXP001_DATA_STATUS')))
        add('BR-AUDIT-EXP001-' + suffix.upper().replace('_', '-'), 'Relatório complementar histórico obtido do repositório remoto',
            'RECOVERED_COMPLEMENTARY_DOCUMENT', {
                'Arquivo': 'reports/' + name, 'Git remoto': head, 'SHA256': digest(raw),
                'Estado literal no documento': state,
                'Limite': 'Documento de 2026-09-02; não substitui os dois originais ausentes nem comprova estado atual',
                'Proveniência': REPOSITORY + '/blob/' + head + '/reports/' + name,
                'Ressalva adicional': 'Cobertura antiga não prova disponibilidade das features nem cotação válida no corte',
            })
    gaps = [
        ('H14-OU25', 'Seis OU2.5 históricos H14', 'Grade/estado e definição histórica da baseline insuficientes'),
        ('H15-OU25', 'Quatro OU2.5 históricos H15', 'Estados e configurações não satisfazem toda a proveniência exigida'),
        ('EXP001-PILOT', 'reports/exp001_data_pilot_2026-09-02.json', 'Ausente nos arquivos e histórico remoto consultados'),
        ('EXP001-COVERAGE', 'reports/exp001_coverage_audit_2026-09-02.json', 'Ausente nos arquivos e histórico remoto consultados'),
        ('INTEGRATED-XG-V2', 'Identidade integrated_xg_v2', 'Identidade de artefato não resolvida; não inferir equivalência'),
        ('FEATURE-PIT', 'Timestamps históricos de publicação de resultados/features', 'Não podem ser substituídos pelo kickoff ou pela data de obtenção atual'),
    ]
    for key, item, limitation in gaps:
        add('BR-AUDIT-FALTA-' + key, item, 'NOT_RECOVERED_IN_REVIEWED_SOURCES', {
            'O que foi buscado': 'Arquivos preservados, 16 ZIPs, 12 revisões de configuração e Git remoto atualizado',
            'Limite': limitation, 'Preenchimento automático': 'NÃO; não inventar números, timestamps ou equivalências',
        })
    assert len({r['id'] for r in rows}) == len(rows)
    text, evidence, records = '', [], []
    for row in rows:
        start = len(text)
        text += row['text'] + '\n'
        eid = digest(row['text'].encode())
        evidence.append({'id': eid, 'source': SOURCE, 'availability': 'received', 'text': row['text'],
                         'sha256': eid, 'hash_basis': 'received_utf8', 'locator': f'characters:{start}:{start + len(row["text"])}',
                         'start': start, 'end': start + len(row['text']), 'offset_unit': 'unicode_codepoints'})
        records.append({'source_id': row['id'], 'revision': eid, 'kind': 'audit_reconstruction_record',
                        'identity_basis': 'source_assigned', 'source_status': row['state'],
                        'status_axis': 'source_availability', 'mapping': None, 'reason': None,
                        'event_at': None, 'recorded_at': None, 'available_at': None, 'supersedes': [], 'evidence_ids': [eid]})
    (BASE / 'BRASILEIRAO_O_QUE_TEM_E_FALTA.md').write_text(text, encoding='utf-8')
    inbox = BASE / 'publications'
    inbox.mkdir(exist_ok=True)
    packages = []
    for start in range(0, len(records), 30):
        package = validate(seal({
            'contract': 'ResearchSnapshotV1', 'profile': 'local-evidence/1', 'extensions': {},
            'origin': {'domain': 'brasileirao', 'repository': REPOSITORY, 'publisher': PUBLISHER, 'stream': STREAM,
                       'code_revision': head, 'exporter_revision': 'br-audit-reconstruction/1',
                       'inputs': {SOURCE: digest(text.encode())}},
            'exported_at': datetime.now(timezone.utc).isoformat(),
            'restrictions': {'policy': POLICY, 'read': True, 'disclose': False, 'generate': True},
            'coverage': {'scope': 'Inventário auditado; distinção explícita entre original, reconstrução e ausência',
                         'completeness': 'partial', 'included': [SOURCE],
                         'missing': [item for _, item, _ in gaps],
                         'excluded': ['protected cohort outcomes', 'personal data', 'private configuration'],
                         'limitations': ['Local derived audit, not producer-authenticated historical forecasts',
                                         'Historical reports are not current verification',
                                         'No reconstructed value restores prospective eligibility']},
            'records': records[start:start+30], 'evidence': evidence[start:start+30]}))
        (inbox / (package['publication_id'] + '.json')).write_bytes(canonical(package))
        packages.append(package['publication_id'])
    manifest = {'records': rows, 'packages': packages, 'original_hashes': originals,
                'remote_head': head, 'source': SOURCE, 'record_count': len(records), 'source_sha256': digest(text.encode())}
    (BASE / 'manifest.json').write_text(json.dumps(manifest, ensure_ascii=False, indent=2), encoding='utf-8')
    print(json.dumps({'records': len(records), 'packages': len(packages), 'complementary_documents_obtained': 3}))


if __name__ == '__main__':
    build()
