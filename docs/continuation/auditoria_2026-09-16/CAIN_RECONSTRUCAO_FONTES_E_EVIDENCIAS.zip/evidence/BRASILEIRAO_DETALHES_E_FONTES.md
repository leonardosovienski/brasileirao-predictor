| ID | Hipótese | Estado | Disponível | Ainda falta | Relatórios originais ausentes | Reconstrução | Limite |
| --- | --- | --- | --- | --- | --- | --- | --- |
| BR-AUDIT-DADOS-HISTORICOS-FALTANTES | Dados históricos faltantes: quais dados históricos ainda faltam e quais existem | DOCUMENTARY_DETAIL | 29 entradas de trials, 3 claims, 12 previsões 1X2 originais, 2 OU2.5 H15 reconstruídos, 3 relatórios complementares obtidos | 6 OU2.5 H14; 4 OU2.5 H15; 2 relatórios originais EXP-001; identidade integrated_xg_v2; ligação H11; timestamps históricos PIT | exp001_data_pilot_2026-09-02.json e exp001_coverage_audit_2026-09-02.json | 2 de 6 braços H15 e 0 de 6 H14; nenhum OU2.5 original registrado; originais preservados | Ausente nas fontes consultadas; não declarar inexistência global nem imputar informação como observada |

| ID | Hipótese | Estado | Regra: id | Regra: family | Regra: status | Regra: legacy_cohorts_eligible | Regra: reconstructions_eligible | Regra: capital_enabled | Regra: activation |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| BR-AUDIT-PROTOCOLO-DETALHE-1 | Protocolo sucessor: definições completas; ainda não ativado | DOCUMENTARY_DETAIL | br-prospective-repair-v2-20260915 | ["h14-successor-v2", "h15-successor-v2"] | SPECIFIED_NOT_ACTIVATED | false | false | false | separate immutable registration and new empty ledgers required; no scheduler installed |

| ID | Hipótese | Estado | Regra: minimum_sample_per_member | Regra: intermediate_evaluations | Regra: evaluation_order | Regra: cohort | Regra: prediction_window_hours | Regra: model | Regra: h15_refit_games |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| BR-AUDIT-PROTOCOLO-DETALHE-2 | Protocolo sucessor: definições completas; ainda não ativado | DOCUMENTARY_DETAIL | 900 | false | ["kickoff_at_utc", "event_id"] | same first 900 eligible event IDs in both members; freeze enrollment before outcome access | 24 | {"algorithm": "nbdc-normalized-elo-horizon-v2", "configuration": "freeze exact relevant configuration at separate activation", "elo_policy": "frozen with each refit state", "ensemble_xg_enabled": false, "fit_inputs": "finalized and received before training cutoff; no future timestamps", "h14_retrain_games": 100} | {"control": 100, "treatment": 10} |

| ID | Hipótese | Estado | Regra: h14_baseline | Regra: required_escrow |
| --- | --- | --- | --- | --- |
| BR-AUDIT-PROTOCOLO-DETALHE-3 | Protocolo sucessor: definições completas; ainda não ativado | DOCUMENTARY_DETAIL | {"cutoff": "00:00 UTC on the preceding calendar date", "date_block": "UTC fixture date", "eligibility": "final_at and available_at strictly before cutoff", "late_arrivals": "not included retrospectively; same frozen snapshot per block", "minimum_history": 200, "one_x_two": "Dirichlet(1,1,1)", "over_2_5": "Beta(1,1); (over_count + 1)/(n + 2)"} | ["full_model_state", "model_source", "relevant_configuration", "full_precision_1x2_and_ou25", "training_cutoff", "prediction_receipt"] |

| ID | Hipótese | Estado | Regra: metrics | Regra: one_x_two_order | Regra: rps | Regra: log_loss | Regra: brier_1x2 | Regra: brier_ou25 | Regra: gain |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| BR-AUDIT-PROTOCOLO-DETALHE-4 | Protocolo sucessor: definições completas; ainda não ativado | DOCUMENTARY_DETAIL | ["rps", "log_loss", "brier_1x2", "brier_ou25"] | ["away", "draw", "home"] | sum of two squared cumulative errors / 2 | natural log; observed-class probability floor 1e-12 | sum over three classes | 2 * (p_over - I(total_goals >= 3))**2 | control_loss minus treatment_loss |

| ID | Hipótese | Estado | Regra: bootstrap/scheme | Regra: bootstrap/block_length | Regra: bootstrap/n_boot | Regra: bootstrap/seed | Regra: bootstrap/rng | Regra: bootstrap/sampling | Regra: bootstrap/ci | Regra: bootstrap/p_null | Regra: bootstrap/p_formula | Regra: bootstrap/ties | Regra: bootstrap/degenerate | Regra: bootstrap/validity | Regra: decision |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| BR-AUDIT-PROTOCOLO-DETALHE-5 | Protocolo sucessor: definições completas; ainda não ativado | DOCUMENTARY_DETAIL | moving non-circular overlapping blocks | 21 | 10000 | 42 | NumPy PCG64 | ceil(n/21) independent block starts; concatenate then truncate to n | percentile 2.5/97.5; NumPy linear quantile | one-sided H0 mean_gain <= 0; centered resampled means | (1 + count(bootstrap_mean - observed_mean >= observed_mean))/(10000 + 1) | included in upper tail | constant gains produce inconclusive p=1, never approval | approximate; requires suitable weak dependence and stationarity | {"family_alpha": 0.05, "family_complete": true, "guardrails": "each lower CI >= 0; uncertain interval is inconclusive", "interpretation": "engineering decision only until prospective provenance is admitted", "noninferiority_margin": 0.0, "primary": "RPS lower CI > 0 and Holm-adjusted one-sided p <= 0.05"} |

| ID | Hipótese | Estado | Arquivo | schema_version | audited_at | Ressalva da auditoria | SHA256 do documento completo |
| --- | --- | --- | --- | --- | --- | --- | --- |
| BR-AUDIT-DOC-COVERAGE-IDENTITY-ASSESSMENT-1 | Relatório complementar histórico de 2026-09-02; bloco 1 de 6 | DOCUMENTARY_DETAIL | exp001_coverage_identity_assessment_2026-09-02.json | exp001-coverage-identity-assessment/1.0 | 2026-09-02 | Estado declarado em 2026-09-02; cobertura antiga não prova validade no cutoff; não substitui originais ausentes | 215e92932b6763ede1aa563ecc06bbc8641b59e077ff4277f96e37a90441bfc4 |

| ID | Hipótese | Estado | Arquivo | coverage_source | provider_period | Ressalva da auditoria | SHA256 do documento completo |
| --- | --- | --- | --- | --- | --- | --- | --- |
| BR-AUDIT-DOC-COVERAGE-IDENTITY-ASSESSMENT-2 | Relatório complementar histórico de 2026-09-02; bloco 2 de 6 | DOCUMENTARY_DETAIL | exp001_coverage_identity_assessment_2026-09-02.json | reports/exp001_coverage_audit_2026-09-02.json | ["2026-01-01", "2026-09-02"] | Estado declarado em 2026-09-02; cobertura antiga não prova validade no cutoff; não substitui originais ausentes | 215e92932b6763ede1aa563ecc06bbc8641b59e077ff4277f96e37a90441bfc4 |

| ID | Hipótese | Estado | Arquivo | fixture_count | errors_after_retry | Ressalva da auditoria | SHA256 do documento completo |
| --- | --- | --- | --- | --- | --- | --- | --- |
| BR-AUDIT-DOC-COVERAGE-IDENTITY-ASSESSMENT-3 | Relatório complementar histórico de 2026-09-02; bloco 3 de 6 | DOCUMENTARY_DETAIL | exp001_coverage_identity_assessment_2026-09-02.json | 245 | 0 | Estado declarado em 2026-09-02; cobertura antiga não prova validade no cutoff; não substitui originais ausentes | 215e92932b6763ede1aa563ecc06bbc8641b59e077ff4277f96e37a90441bfc4 |

| ID | Hipótese | Estado | Arquivo | requests_used | horizons/H-24h | horizons/H-6h | horizons/H-1h | Ressalva da auditoria |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| BR-AUDIT-DOC-COVERAGE-IDENTITY-ASSESSMENT-4-P1 | Relatório complementar histórico de 2026-09-02; bloco 4 de 6 | DOCUMENTARY_DETAIL | exp001_coverage_identity_assessment_2026-09-02.json | 247 | {"coverage": 1.0, "covered": 245, "max_age_minutes": 2879.021, "median_age_minutes": 479.342, "p95_age_minutes": 719.237, "within_1440_minutes": 242, "within_360_minutes": 101, "within_60_minutes": 20} | {"coverage": 1.0, "covered": 245, "max_age_minutes": 3959.021, "median_age_minutes": 52.504, "p95_age_minutes": 119.002, "within_1440_minutes": 241, "within_360_minutes": 241, "within_60_minutes": 129} | {"coverage": 1.0, "covered": 245, "max_age_minutes": 4259.021, "median_age_minutes": 24.451, "p95_age_minutes": 59.248, "within_1440_minutes": 242, "within_360_minutes": 242, "within_60_minutes": 241} | Estado declarado em 2026-09-02; cobertura antiga não prova validade no cutoff; não substitui originais ausentes |

| ID | Hipótese | Estado | SHA256 do documento completo |
| --- | --- | --- | --- |
| BR-AUDIT-DOC-COVERAGE-IDENTITY-ASSESSMENT-4-P2 | Relatório complementar histórico de 2026-09-02; bloco 4 de 6 | DOCUMENTARY_DETAIL | 215e92932b6763ede1aa563ecc06bbc8641b59e077ff4277f96e37a90441bfc4 |

| ID | Hipótese | Estado | Arquivo | identity_and_kickoff | older_period_probes | Ressalva da auditoria |
| --- | --- | --- | --- | --- | --- | --- |
| BR-AUDIT-DOC-COVERAGE-IDENTITY-ASSESSMENT-5-P1 | Relatório complementar histórico de 2026-09-02; bloco 5 de 6 | DOCUMENTARY_DETAIL | exp001_coverage_identity_assessment_2026-09-02.json | {"internal_completed_2026": 225, "matched_by_exact_utc_kickoff_and_explicit_team_aliases": 225, "provider_fixtures": 245, "provider_only_after_internal_database_max_kickoff": 20, "unmatched_internal": 0, "verdict": "all overlapping internal fixtures matched; the local database ends earlier than the provider population"} | [{"fixture_catalog_available": true, "sample_historical_odds_status": 404, "sample_result": "No historical odds found", "season": 2024}, {"fixture_catalog_available": true, "sample_historical_odds_status": 404, "sample_result": "No historical odds found", "season": 2025}] | Estado declarado em 2026-09-02; cobertura antiga não prova validade no cutoff; não substitui originais ausentes |

| ID | Hipótese | Estado | SHA256 do documento completo |
| --- | --- | --- | --- |
| BR-AUDIT-DOC-COVERAGE-IDENTITY-ASSESSMENT-5-P2 | Relatório complementar histórico de 2026-09-02; bloco 5 de 6 | DOCUMENTARY_DETAIL | 215e92932b6763ede1aa563ecc06bbc8641b59e077ff4277f96e37a90441bfc4 |

| ID | Hipótese | Estado | Arquivo | limitations/0 | limitations/1 | limitations/2 | limitations/3 | data_status | Ressalva da auditoria | SHA256 do documento completo |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| BR-AUDIT-DOC-COVERAGE-IDENTITY-ASSESSMENT-6 | Relatório complementar histórico de 2026-09-02; bloco 6 de 6 | DOCUMENTARY_DETAIL | exp001_coverage_identity_assessment_2026-09-02.json | coverage is complete for returned 2026 fixtures but not multi-season | three to four fixtures per horizon have snapshots more than 24 hours older than the requested cutoff | a maximum-age inclusion rule must be preregistered before performance is inspected | the internal outcomes database must be updated for the 20 latest provider fixtures before evaluation | PARTIALLY_READY | Estado declarado em 2026-09-02; cobertura antiga não prova validade no cutoff; não substitui originais ausentes | 215e92932b6763ede1aa563ecc06bbc8641b59e077ff4277f96e37a90441bfc4 |

| ID | Hipótese | Estado | Arquivo | schema_version | audited_at | Ressalva da auditoria | SHA256 do documento completo |
| --- | --- | --- | --- | --- | --- | --- | --- |
| BR-AUDIT-DOC-FEATURE-PIT-AUDIT-1 | Relatório complementar histórico de 2026-09-02; bloco 1 de 5 | DOCUMENTARY_DETAIL | exp001_feature_pit_audit_2026-09-02.json | exp001-feature-pit-audit/1.0 | 2026-09-02 | Estado declarado em 2026-09-02; cobertura antiga não prova validade no cutoff; não substitui originais ausentes | f83662255c4236e938af227728332019b8f7123f5a8369d7728eb13028ee6307 |

| ID | Hipótese | Estado | Arquivo | incumbent | database_evidence | Ressalva da auditoria | SHA256 do documento completo |
| --- | --- | --- | --- | --- | --- | --- | --- |
| BR-AUDIT-DOC-FEATURE-PIT-AUDIT-2 | Relatório complementar histórico de 2026-09-02; bloco 2 de 5 | DOCUMENTARY_DETAIL | exp001_feature_pit_audit_2026-09-02.json | {"ensemble_xg_enabled": false, "primary_historical_inputs": ["prior match score", "prior match kickoff", "home and away team identity", "neutral venue flag"]} | {"match_statistics_rows": 439764, "player_comp_stats_rows": 5210, "player_comp_stats_with_available_at": 5210, "sofascore_paired_xg": 2124, "sofascore_played": 2125, "sofascore_played_with_kickoff_at": 2125} | Estado declarado em 2026-09-02; cobertura antiga não prova validade no cutoff; não substitui originais ausentes | f83662255c4236e938af227728332019b8f7123f5a8369d7728eb13028ee6307 |

| ID | Hipótese | Estado | Arquivo | critical_timestamp_gaps/0 | critical_timestamp_gaps/1 | critical_timestamp_gaps/2 | horizon_verdicts |
| --- | --- | --- | --- | --- | --- | --- | --- |
| BR-AUDIT-DOC-FEATURE-PIT-AUDIT-3-P1 | Relatório complementar histórico de 2026-09-02; bloco 3 de 5 | DOCUMENTARY_DETAIL | exp001_feature_pit_audit_2026-09-02.json | {"fields": ["home_score", "away_score", "home_xg", "away_xg"], "impact": "a prior kickoff proves when a match began, not when its result became available", "missing_provenance": "result_published_at or completed_at", "table": "sofascore_matches"} | {"fields": ["value"], "impact": "statistics cannot be admitted into an exact historical cutoff reconstruction", "missing_provenance": "available_at and ingested_at", "table": "match_statistics"} | {"fields": ["odds_home", "odds_draw", "odds_away"], "impact": "embedded aggregate odds are not an admissible EXP-001 market baseline", "missing_provenance": "bookmaker identity and quote timestamp", "table": "sofascore_matches"} | {"H-1h": "NOT_PROVEN", "H-24h": "NOT_PROVEN", "H-6h": "NOT_PROVEN"} |

| ID | Hipótese | Estado | Ressalva da auditoria | SHA256 do documento completo |
| --- | --- | --- | --- | --- |
| BR-AUDIT-DOC-FEATURE-PIT-AUDIT-3-P2 | Relatório complementar histórico de 2026-09-02; bloco 3 de 5 | DOCUMENTARY_DETAIL | Estado declarado em 2026-09-02; cobertura antiga não prova validade no cutoff; não substitui originais ausentes | f83662255c4236e938af227728332019b8f7123f5a8369d7728eb13028ee6307 |

| ID | Hipótese | Estado | Arquivo | decision | reason | Ressalva da auditoria | SHA256 do documento completo |
| --- | --- | --- | --- | --- | --- | --- | --- |
| BR-AUDIT-DOC-FEATURE-PIT-AUDIT-4 | Relatório complementar histórico de 2026-09-02; bloco 4 de 5 | DOCUMENTARY_DETAIL | exp001_feature_pit_audit_2026-09-02.json | FAIL_CLOSED | the repository can reject explicitly late observations, but the preserved historical score rows do not carry an availability timestamp sufficient to prove that every model input existed at each requested cutoff | Estado declarado em 2026-09-02; cobertura antiga não prova validade no cutoff; não substitui originais ausentes | f83662255c4236e938af227728332019b8f7123f5a8369d7728eb13028ee6307 |

| ID | Hipótese | Estado | Arquivo | allowed_next_step | Ressalva da auditoria | SHA256 do documento completo |
| --- | --- | --- | --- | --- | --- | --- |
| BR-AUDIT-DOC-FEATURE-PIT-AUDIT-5 | Relatório complementar histórico de 2026-09-02; bloco 5 de 5 | DOCUMENTARY_DETAIL | exp001_feature_pit_audit_2026-09-02.json | obtain source publication timestamps or define a prospectively collected bitemporal cohort; do not impute historical availability and call it observed | Estado declarado em 2026-09-02; cobertura antiga não prova validade no cutoff; não substitui originais ausentes | f83662255c4236e938af227728332019b8f7123f5a8369d7728eb13028ee6307 |

| ID | Hipótese | Estado | Arquivo | schema_version | decided_at | Ressalva da auditoria | SHA256 do documento completo |
| --- | --- | --- | --- | --- | --- | --- | --- |
| BR-AUDIT-DOC-READINESS-DECISION-1 | Relatório complementar histórico de 2026-09-02; bloco 1 de 6 | DOCUMENTARY_DETAIL | exp001_readiness_decision_2026-09-02.json | exp001-readiness-decision/1.0 | 2026-09-02 | Estado declarado em 2026-09-02; cobertura antiga não prova validade no cutoff; não substitui originais ausentes | b9eb9c805e6678e36790dc46c3670f803e5b1ee61dd3ebd4e6c6c02ef5457a72 |

| ID | Hipótese | Estado | Arquivo | preservation/status | preservation/verified_offsite_bundle | preservation/verified_exact_source_bundle | preservation/remaining | trial_schema | Ressalva da auditoria | SHA256 do documento completo |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| BR-AUDIT-DOC-READINESS-DECISION-2 | Relatório complementar histórico de 2026-09-02; bloco 2 de 6 | DOCUMENTARY_DETAIL | exp001_readiness_decision_2026-09-02.json | BLOCKED | C:\Users\Superleo13\OneDrive\Codex-Offsite\brasileirao-predictor\20260903T001757Z | C:\Users\Superleo13\OneDrive\Codex-Offsite\brasileirao-predictor\source-originals-20260902T233806Z | ["original general prediction store not located", "original dedicated prospective database not located"] | {"core_version": "3.1.0", "idempotent": true, "legacy_trials": 29, "migrated_trials": 29, "status": "PASS", "unique_trial_ids": 29, "validation_errors": 0} | Estado declarado em 2026-09-02; cobertura antiga não prova validade no cutoff; não substitui originais ausentes | b9eb9c805e6678e36790dc46c3670f803e5b1ee61dd3ebd4e6c6c02ef5457a72 |

| ID | Hipótese | Estado | Arquivo | harness | market_data | Ressalva da auditoria | SHA256 do documento completo |
| --- | --- | --- | --- | --- | --- | --- | --- |
| BR-AUDIT-DOC-READINESS-DECISION-3 | Relatório complementar histórico de 2026-09-02; bloco 3 de 6 | DOCUMENTARY_DETAIL | exp001_readiness_decision_2026-09-02.json | {"core_version": "3.1.0", "executed_at": "2026-09-02T23:37:28Z", "expires_at": "2026-09-09T23:37:28Z", "status": "PASS"} | {"coverage_H1": 1.0, "coverage_H24": 1.0, "coverage_H6": 1.0, "fixtures": 245, "multi_season_history": false, "stale_outliers_present": true, "status": "PASS_FOR_2026_COVERAGE_ONLY"} | Estado declarado em 2026-09-02; cobertura antiga não prova validade no cutoff; não substitui originais ausentes | b9eb9c805e6678e36790dc46c3670f803e5b1ee61dd3ebd4e6c6c02ef5457a72 |

| ID | Hipótese | Estado | Arquivo | model_feature_pit | EXP001_DATA_STATUS | Ressalva da auditoria | SHA256 do documento completo |
| --- | --- | --- | --- | --- | --- | --- | --- |
| BR-AUDIT-DOC-READINESS-DECISION-4 | Relatório complementar histórico de 2026-09-02; bloco 4 de 6 | DOCUMENTARY_DETAIL | exp001_readiness_decision_2026-09-02.json | {"H1": "NOT_PROVEN", "H24": "NOT_PROVEN", "H6": "NOT_PROVEN", "reason": "historical score and xG records lack result_published_at/completed_at", "status": "FAIL_CLOSED"} | PARTIALLY_READY | Estado declarado em 2026-09-02; cobertura antiga não prova validade no cutoff; não substitui originais ausentes | b9eb9c805e6678e36790dc46c3670f803e5b1ee61dd3ebd4e6c6c02ef5457a72 |

| ID | Hipótese | Estado | Arquivo | EXP001_EXECUTION | EXP001_PROTOCOL | Ressalva da auditoria | SHA256 do documento completo |
| --- | --- | --- | --- | --- | --- | --- | --- |
| BR-AUDIT-DOC-READINESS-DECISION-5 | Relatório complementar histórico de 2026-09-02; bloco 5 de 6 | DOCUMENTARY_DETAIL | exp001_readiness_decision_2026-09-02.json | NOT_STARTED | NOT_REGISTERED_BECAUSE_DATA_NOT_READY | Estado declarado em 2026-09-02; cobertura antiga não prova validade no cutoff; não substitui originais ausentes | b9eb9c805e6678e36790dc46c3670f803e5b1ee61dd3ebd4e6c6c02ef5457a72 |

| ID | Hipótese | Estado | Arquivo | BR_RESEARCH_DECISION | Ressalva da auditoria | SHA256 do documento completo |
| --- | --- | --- | --- | --- | --- | --- |
| BR-AUDIT-DOC-READINESS-DECISION-6 | Relatório complementar histórico de 2026-09-02; bloco 6 de 6 | DOCUMENTARY_DETAIL | exp001_readiness_decision_2026-09-02.json | UNKNOWN | Estado declarado em 2026-09-02; cobertura antiga não prova validade no cutoff; não substitui originais ausentes | b9eb9c805e6678e36790dc46c3670f803e5b1ee61dd3ebd4e6c6c02ef5457a72 |

